<?php
session_start();//session start
$uname="sdf";$user_id="";$buyername="";$buyer_id="";$dobs="";
if(isset($_SESSION['username']))
	{
		$user_id= $_SESSION['user_id'];
		$uname ="Welcome to "."". $_SESSION['username'];
		
	}
	else{
		header('Location:index.php');
	}
	if(isset($_SESSION['buyername']))
	{
		$buyername= $_SESSION['buyername'];
		$dobs= $_SESSION['dobs'];
		include('db.php');
		$qu="select bid from buyer_info where buyer_name='$buyername' and buyer_dob='$dobs'";
		$re=mysql_query($qu);
		while($data=mysql_fetch_row($re))
		{
			$buyer_id=$data[0];
		}
		
	}
	?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title>ONLINE VEHICLE REGISTRATION SYSTEM</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width">
        <link href="css/style1.css" rel="stylesheet" type="text/css" />
		<link rel="stylesheet" href="css/sliding.css" type="text/css" media="screen" />
        <link rel="shortcut icon" href="./images/pwsicon.png">
     <script type="text/javascript">


function changeHashOnLoad() {
    window.location.href += "#";
    setTimeout("changeHashAgain()", "50"); 
}

function changeHashAgain() {
 window.location.href += "1";
}

var storedHash = window.location.hash;
window.setInterval(function () {
   if (window.location.hash != storedHash) {
        window.location.hash = storedHash;
   }
}, 50);

</script>

    </head>
<body onload="changeHashOnLoad();">
   <div class="wrapper">
       <img width="960" src="images/rtohead.png" alt=""/>
	   <div class="menu">
     <ul class="blue">
	<li><a href="userhome.php" title="Home"><span>Home</span></a></li>
	<li><a href="newregister.php" title="Registered Details" class="current" ><span>Registered Details</span></a></li>
    <li><a href="newregister.php" title="New Registration"  ><span>New Registration</span></a></li>
    <li><a href="useravailableno.php" title="Vehicle Number"><span>Vehicle Numbers</span></a></li>
	
     <li><a href="contact.php" title="Contact" ><span>Contact</span></a></li>
	<li><?php echo $uname; ?></li>
	<li><a href="logout.php">Logout</a></li>
</ul>
</div>
  <div class="clear">
  </div>
  
   
   
 <div class="content">
 <h3 align="center">FORM 20</h3>
<h3 align="center" style="font-style: normal;">APPLICATION FOR REGISTRATION OF A MOTOR VEHICLE</h3>
<h4 align="center">[See Rule 47]</h4>
<p style="text-align: justify;">(To be made in duplicate if the vehicle is held under an agreement of Hire-
Purchase/Lease/Hypothecation and duplicate copy with the endorsement of Registering
Authority to be returned to the Financier simultaneous on Registration of motor vehicle)</p>
<br>
  <form action="form20_process.php" method="post">
  	<table>
	<input type="hidden" name="user_id" value="<?php echo $user_id; ?>"/>
	<input type="hidden" name="buyer_id" value="<?php echo $buyer_id; ?>"/>
		<tr>
			<td>
				(1).Name of Person
			</td>
			<td>
				<input type="text" name="name" value="<?php echo $buyername; ?>"/>
			</td>
			<td>
				(2).Age of Person
			</td>
			<td>
				<input type="text" name="age"/>
			</td>
		</tr>
		
		<tr>
			<td>
				(3).Permanent Address
			</td>
			<td>
				<textarea rows="3" cols="35" name="permanent"></textarea>
			</td>
			<td>
				(4).Temporary Address
			</td>
			<td>
				<textarea rows="3" cols="35" name="temp"></textarea>
			</td>
			
		</tr>
		<tr>
			<td>
				(5).Name and address of the Manufacturer from whom the vehicle was purchased
			</td>
			<td>
				<textarea rows="3" cols="35" name="manufacturer"></textarea>
			</td>
			
			<td>
				(6).If ex-army vehicles or imported vehicle
			</td>
			<td>
				<textarea rows="3" cols="35" name="exarmy"></textarea>
			</td>
		</tr>
		
		<tr>
			<td>
				(7).Class of vehicle
			</td>
			<td>
				<input type="text" name="class"/>
			</td>
			<td>
				(8).Type of body
			</td>
			<td>
				<input type="text" name="body"/>
			</td>
		</tr>
		
		<tr>
			<td>
				<p style="font-style: arial;">(9).The Motor vehicle is</p>
			</td>
		</tr>
		<tr>
			<td>
				(a).a new vehicle
			</td>
			<td>
				<input type="text" name="newvehicle"/>
			</td>
				<td>
				(10).Tyle of vehicle
			</td>
			<td>
				<input type="text" name="typeofvehicle"/>
			</td>
		</tr>
		<tr>
			<td>
				(b).Ex-army vehicle
			</td>
			<td>
				<input type="text" name="exarmy1"/>
			</td>
			<td>
				(11).Makers Name
			</td>
			<td>
				<input type="text" name="makersname"/>
			</td>
		</tr>
		<tr>
			<td>
				(c).imported vehicle
			</td>
			<td>
				<input type="text" name="imported"/>
			</td>
			<td>
				(12).Month and year of manufacturer
			</td>
			<td>
				<input type="text" name="monthyear"/>
			</td>
		</tr>
		
		
		<tr>
			<td>
				(13).Number of cylinders
			</td>
			<td>
				<input type="text" name="cylinders"/>
			</td>
			<td>
				(14).Horse power
			</td>
			<td>
				<input type="text" name="horsepower"/>
			</td>
		</tr>
		
		<tr>
			<td>
				(15).Cubic capacity
			</td>
			<td>
				<input type="text" name="cubic"/>
			</td>
			<td>
				(16).Maker's classification or if not known,
			</td>
			<td>
				<input type="text" name="makersclassi"/>
			</td>
		</tr>
		
		<tr>
			<td>
				(17).Wheel base
			</td>
			<td>
				<input type="text" name="wheelbase"/>
			</td>
			<td>
				(18).Chassis No. (Affix Pencil print)
			</td>
			<td>
				<input type="text" name="chassis"/>
			</td>
		</tr>
		
		<tr>
			<td>
				(19).Seating capacity (including driver)
			</td>
			<td>
				<input type="text" name="seating"/>
			</td>
			<td>
				(20).Fuel used in the engine
			</td>
			<td>
				<input type="text" name="fuel"/>
			</td>
		</tr>
		
		<tr>
			<td>
				(21).Unladen weight
			</td>
			<td>
				<input type="text" name="unladenweighta"/>
			</td>
			<td>
				(22).Particulars of previous registration and registered number
			</td>
			<td>
				<input type="text" name="previousnumber"/>
			</td>
		</tr>
		
		<tr>
			<td>
				(23).Colour or colour of body
			</td>
			<td>
				<input type="text" name="color"/>
			</td>
			<td>
				(24).Type of body
			</td>
			<td>
				<input type="text" name="typeofbody"/>
			</td>
		</tr>
		
		<tr>
			<td>
				(25).Number, description and size of tyres
			</td>
			<td>
				
			</td>
			<td>
				(26).Maximum axle weight
			</td>
			
		</tr>
		
		<tr>
			<td>
				(a) Front axle
			</td>
			<td>
				<input type="text" name="frontaxle"/>
			</td>
			<td>
				(a) Front axle
			</td>
			<td>
				<input type="text" name="wfrontaxle"/>
			</td>
			
		</tr>
		<tr>
			<td>
				(b) Rear axle
			</td>
			<td>
				<input type="text" name="rearaxle"/>
			</td>
			<td>
				(b) Rear axle
			</td>
			<td>
				<input type="text" name="wrearaxle"/>
			</td>
			
		</tr>
		
		<tr>
			<td>
				(c) Any other axle
			</td>
			<td>
				<input type="text" name="otheraxle"/>
			</td>
			<td>
				(c) Any other axle
			</td>
			<td>
				<input type="text" name="wotheraxle"/>
			</td>
			
		</tr>
		<tr>
			<td>
				(d) Tandem axle
			</td>
			<td>
				<input type="text" name="tandomaxle"/>
			</td>
			<td>
				(d) Tandem axle
			</td>
			<td>
				<input type="text" name="wtandomaxle"/>
			</td>
			
		</tr>
		
		<tr>
			<td>
				(27).Gross vehicle weight
			</td>
			<td>
				
			</td>
			</tr>
			<tr>
			<td>
				(a) As certified by the manufacture
			</td>
			<td>
				<input type="text" name="certified"/>Kgms
			</td>
			<td>
				(b) To be registered
			</td>
			<td>
				<input type="text" name="toberegistered"/>Kgms
			</td>
			
		</tr>
		
		<tr>
			<td>
				(28).Overall
			</td>
			<td>
				
			</td>
		</tr>
		<tr>
			<td>
				(a) Overall length
			</td>
			<td>
				<input type="text" name="overalllength"/>
			</td>
			<td>
				(b) Overall width
			</td>
			<td>
				<input type="text" name="overallweight"/>
			</td>
		</tr>
		
		<tr>
			<td>
				(c) Overall height
			</td>
			<td>
				<input type="text" name="overallheight"/>
			</td>
			<td>
				(d) Over hang
			</td>
			<td>
				<input type="text" name="overallhang"/>
			</td>
		</tr>
		
		<tr>
			<td>
				(29).Number, description and size of tyres on each axle
			</td>
			<td>
				<input type="text" name="eachaxle"/>
			</td>
			<td>
				(30).Maximum axle weight in respect of each 
			</td>
			<td>
				<input type="text" name="maximumaxle"/>
			</td>
		</tr>
		
		
		<tr>
			<td>
				(31).Insurance certificate company
			</td>
			<td>
				<input type="text" name="insurance"/>
			</td>
			<td>
				(32).The vehicle is exempted from Insurance.
			</td>
			<td>
				<input type="text" name="exempted"/>
			</td>
		</tr>
		
		<tr>
			<td>
				(33).I have paid the prescribed fee of rupees
			</td>
			<td>
				<input type="text" name="prescribed"/>
			</td>
			
		</tr>
		
		<tr>
			<td>
				
			</td>
			<td>
				
			</td>
			
		</tr>
		
		<tr>
			<td>
				
			</td>
			<td>
				<input type="submit" name="submit" value="Submit"/>
				<input type="reset" name="Reset"/>
			</td>
			
		</tr>
	</table>
  </form>
   </div>
 </div>
   
</body>
</html>
