<?php
session_start();//session start
$uname="";$user_id="";
if(isset($_SESSION['adminname']))
	{
		$user_id= $_SESSION['admin_id'];
		$uname ="Welcome to "."". $_SESSION['adminname'];
		
	}
	else{
		header('Location:index.php');
	}
	
	?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title>ONLINE VEHICLE REGISTRATION SYSTEM</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width">
        <link href="css/style1.css" rel="stylesheet" type="text/css" />
		<link rel="stylesheet" href="css/sliding.css" type="text/css" media="screen" />
        <link rel="shortcut icon" href="./images/pwsicon.png">
     <script type="text/javascript">


function changeHashOnLoad() {
    window.location.href += "#";
    setTimeout("changeHashAgain()", "50"); 
}

function changeHashAgain() {
 window.location.href += "1";
}

var storedHash = window.location.hash;
window.setInterval(function () {
   if (window.location.hash != storedHash) {
        window.location.hash = storedHash;
   }
}, 50);

</script>

    </head>
<body onload="changeHashOnLoad();">
   <div class="wrapper">
       <img width="960" src="images/rtohead.png" alt=""/>
	   <div class="menu">
     <ul class="blue">
	<li><a href="adminhome.php" title="Home"><span>Home</span></a></li>
	<li><a href="userdetails.php" title="Registered Details" class="current"><span>User Details</span></a></li>
	<li><a href="regdetails.php" title="Registered Details" ><span>Registered Details</span></a></li>
    <li><a href="rto.php" title="RTO"><span>RTO</span></a></li>
   
	<li><font color="#f9600d"> <?php echo $uname; ?></font></li>
	<li><a href="logout.php">Logout</a></li>
</ul>
</div>
  <div class="clear">
  </div>
  
   
   
 <div class="content">
 <br>
 <h3 align="center">User Information</h3>
  
  <table align="center" border="2">
  <tr>
  	<th>Show Room Name</th>
	<th>Reg No</th>
	<th>Owner Name</th>
	<th>DOB</th>
	<th>Mail</th>
	<th>Phone</th>
	<th>Mobile</th>
	<th>Fax No</th>
	<th>Address</th>
	<th>Status</th>
	<th>Link</th>
  </tr>
  <?php
  include('db.php');
  $query="select * from l_users";
  $result=mysql_query($query);
  while($data=mysql_fetch_row($result))
  {
  ?>
  <tr>
  <td><?php echo $data[1]; ?></td>
  <td><?php echo $data[2]; ?></td>
  <td><?php echo $data[3]; ?></td>
  <td><?php echo $data[6]; ?></td>
  <td><?php echo $data[7]; ?></td>
  <td><?php echo $data[8]; ?></td>
  <td><?php echo $data[9]; ?></td>
  <td><?php echo $data[10]; ?></td>
  <td><?php echo $data[11]; ?></td>
  <td><?php echo $data[13]; ?></td>
  <td><a href="status.php?id=<?php echo $data[0]; ?>">Select</a></td>
  <?php	
  }
  ?>
  </table>
  
   </div>
 </div>
   
</body>
</html>
