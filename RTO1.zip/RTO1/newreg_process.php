<?php
ob_start();
session_start();
include('db.php');
$date=$_POST['date'];
$user_id=$_POST['user_id'];
$buyername=$_POST['buyername'];
$dob=$_POST['dob'];
$mobile=$_POST['mobile'];
$status='Waiting';

$sql="insert into buyer_info(date,buyer_name,buyer_dob,contact_no,user_id,status)values('$date','$buyername','$dob','$mobile','$user_id','$status')";

$result=mysql_query($sql);
if($result)
{
	session_regenerate_id();
     $_SESSION['buyername'] = $buyername;
     $_SESSION['dobs'] = $dob;
	session_write_close();
	$url="form20.php";
    session_write_close();
	 echo '<script language="javascript">alert("Register Successfully");location.href=\'' . $url . '\'</script>';
}
else
{
	 echo '<script language="javascript">alert("Please Try Again");location.href=\'' . $_SERVER['HTTP_REFERER'] . '\'</script>';
}

?>