<?php
session_start();//session start
$uname="";$user_id="";
if(isset($_SESSION['adminname']))
	{
		$user_id= $_SESSION['admin_id'];
		$uname ="Welcome to "."". $_SESSION['adminname'];
		
	}
	else{
		header('Location:index.php');
	}
	
	?>
	
	
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title>ONLINE VEHICLE REGISTRATION SYSTEM</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width">
        <link href="css/style1.css" rel="stylesheet" type="text/css" />
		<link rel="stylesheet" href="css/sliding.css" type="text/css" media="screen" />
        <link rel="shortcut icon" href="./images/pwsicon.png">
     <script type="text/javascript">


function changeHashOnLoad() {
    window.location.href += "#";
    setTimeout("changeHashAgain()", "50"); 
}

function changeHashAgain() {
 window.location.href += "1";
}

var storedHash = window.location.hash;
window.setInterval(function () {
   if (window.location.hash != storedHash) {
        window.location.hash = storedHash;
   }
}, 50);

</script>

    </head>
<body onload="changeHashOnLoad();">
   <div class="wrapper">
       <img width="960" src="images/rtohead.png" alt=""/>
	   <div class="menu">
     <ul class="blue">
	<li><a href="adminhome.php" title="Home"><span>Home</span></a></li>
	<li><a href="userdetails.php" title="Registered Details" ><span>User Details</span></a></li>
	<li><a href="regdetails.php" title="Registered Details" class="current" ><span>Registered Details</span></a></li>
     <li><a href="rto.php" title="RTO" ><span>RTO</span></a></li>
  
	
   
	<li><font color="#f9600d"> <?php echo $uname; ?></font></li>
	<li><a href="logout.php">Logout</a></li>
</ul>
</div>
  <div class="clear">
  </div>
  
   
   
 <div class="content">
 <br>
 <h3 align="center">Registered Details</h3>
  <table align="center" border="2">
  <tr>
    <th>Date</th>
  	<th>Show Room Name</th>
	<th>Buyer Name</th>
    <th>RTO Office</th>
	<th>Status</th>
	<th>View</th>
  </tr>
  <?php
  include('db.php');
  $query="select p2.date,p1.showroom_name,p2.buyer_name,p3.location,p2.status,p4.f1id,p2.bid
from l_users p1,buyer_info p2,l_rto_regist p3,form20 p4 
where p1.user_id=p2.user_id and p1.rto=p3.rto_id and p4.buyer_id=p2.bid";
  $result=mysql_query($query);
  while($data=mysql_fetch_row($result))
  {
  ?>
  <tr>
  <td><?php echo $data[0]; ?></td>
  <td><?php echo $data[1]; ?></td>
  <td><?php echo $data[2]; ?></td>
  <td><?php echo $data[3]; ?></td>
  <td><?php echo $data[4]; ?></td>
  <td><a href="viewform.php?id=<?php echo $data[6]; ?>&fid=<?php echo $data[6]; ?>">view</a></td>
  <?php	
  }
  ?>
  </table>
 
  
   </div>
 </div>
   
</body>
</html>
