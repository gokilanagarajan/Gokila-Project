<?php
session_start();//session start
$uname="sdf";$user_id="";
if(isset($_SESSION['username']))
	{
		$user_id= $_SESSION['user_id'];
		$uname ="Welcome to "."". $_SESSION['username'];
		
	}
	else{
		header('Location:index.php');
	}
	
	?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title>ONLINE VEHICLE REGISTRATION SYSTEM</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width">
        <link href="css/style1.css" rel="stylesheet" type="text/css" />
		<link rel="stylesheet" href="css/sliding.css" type="text/css" media="screen" />
        <link rel="shortcut icon" href="./images/pwsicon.png">
     <script type="text/javascript">


function changeHashOnLoad() {
    window.location.href += "#";
    setTimeout("changeHashAgain()", "50"); 
}

function changeHashAgain() {
 window.location.href += "1";
}

var storedHash = window.location.hash;
window.setInterval(function () {
   if (window.location.hash != storedHash) {
        window.location.hash = storedHash;
   }
}, 50);

</script>

    </head>
<body onload="changeHashOnLoad();">
   <div class="wrapper">
       <img width="960" src="images/rtohead.png" alt=""/>
     <ul class="blue">
	<li><a href="#" title="Home"  class="current"  ><span>Home</span></a></li>
	<li><a href="registerdetails.php" title="Registered Details"><span>Registered Details</span></a></li>
    
    <li><a href="useravailableno.php" title="Vehicle Number"><span>Vehicle Numbers</span></a></li>
	
     <li><a href="contact.php" title="Contact"><span>Contact</span></a></li>
	<li><font color="#f9600d"> <?php echo $uname; ?></font></li>
	<li><a href="logout.php">Logout</a></li>
</ul>

   </div>
   <div class="clear"></div>
   <p style="margin-left: 370px; margin-top: 60px;">
   
   		<img  src="images/Motorcycle_content.png"/>
   </p>
</body>
</html>
