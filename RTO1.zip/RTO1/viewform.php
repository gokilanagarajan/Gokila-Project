<?php
session_start();//session start
$uname="";$user_id="";
if(isset($_SESSION['adminname']))
	{
		$user_id= $_SESSION['admin_id'];
		$uname ="Welcome to "."". $_SESSION['adminname'];
		
	}
	else{
		header('Location:index.php');
	}
	
	?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title>ONLINE VEHICLE REGISTRATION SYSTEM</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width">
        <link href="css/style1.css" rel="stylesheet" type="text/css" />
		<link rel="stylesheet" href="css/sliding.css" type="text/css" media="screen" />
        <link rel="shortcut icon" href="./images/pwsicon.png">
		
     <script type="text/javascript">


function changeHashOnLoad() {
    window.location.href += "#";
    setTimeout("changeHashAgain()", "50"); 
}

function changeHashAgain() {
 window.location.href += "1";
}

var storedHash = window.location.hash;
window.setInterval(function () {
   if (window.location.hash != storedHash) {
        window.location.hash = storedHash;
   }
}, 50);

</script>

    </head>
<body onload="changeHashOnLoad();">
   <div class="wrapper">
       <img width="960" src="images/rtohead.png" alt=""/>
	   <div class="menu">
     <ul class="blue">
	<li><a href="adminhome.php" title="Home"><span>Home</span></a></li>
	<li><a href="userdetails.php" title="Registered Details" ><span>User Details</span></a></li>
	<li><a href="regdetails.php" title="Registered Details" class="current"><span>Registered Details</span></a></li>
     <li><a href="rto.php" title="RTO"  ><span>RTO</span></a></li>
  
	
    
	<li><font color="#f9600d"> <?php echo $uname; ?></font></li>
	<li><a href="logout.php">Logout</a></li>
</ul>
</div>
  <div class="clear">
  </div>
  
   
   
 <div class="content">
 
 <?php
 $bid=$_GET['id'];
 $sid=$_GET['fid'];
 include('db.php');
 $sql="select * from form20 where buyer_id='$bid'";
 $res=mysql_query($sql);
 while($data=mysql_fetch_row($res))
 {
?>

 <h3 align="center">FORM 20</h3>
<h3 align="center" style="font-style: normal;">APPLICATION FOR REGISTRATION OF A MOTOR VEHICLE</h3>
<h4 align="center">[See Rule 47]</h4>
<p style="text-align: justify;">(To be made in duplicate if the vehicle is held under an agreement of Hire-
Purchase/Lease/Hypothecation and duplicate copy with the endorsement of Registering
Authority to be returned to the Financier simultaneous on Registration of motor vehicle)</p>
<br>
  <form action="viewform2.php" method="post">
  	<table>
	<input type="hidden" name="bid"  value="<?php echo $bid; ?>" />
	<input type="hidden" name="sid"  value="<?php echo $sid; ?>" />
		<tr>
			<td>
				(1).Name of Person
			</td>
			<td>
				<input type="text" name="name" value="<?php echo $data[1]; ?>"/>
			</td>
			<td>
				(2).Age of Person
			</td>
			<td>
				<input type="text" name="age" value="<?php echo $data[2]; ?>"/>
			</td>
		</tr>
		
		<tr>
			<td>
				(3).Permanent Address
			</td>
			<td>
				<textarea rows="3" cols="35" name="permanent"><?php echo $data[3]; ?></textarea>
			</td>
			<td>
				(4).Temporary Address
			</td>
			<td>
				<textarea rows="3" cols="35" name="temp" ><?php echo $data[4]; ?></textarea>
			</td>
			
		</tr>
		<tr>
			<td>
				(5).Name and address of the Manufacturer from whom the vehicle was purchased
			</td>
			<td>
				<textarea rows="3" cols="35" name="manufacturer" ><?php echo $data[5]; ?></textarea>
			</td>
			
			<td>
				(6).If ex-army vehicles or imported vehicle
			</td>
			<td>
				<textarea rows="3" cols="35" name="exarmy" ><?php echo $data[6]; ?></textarea>
			</td>
		</tr>
		
		<tr>
			<td>
				(7).Class of vehicle
			</td>
			<td>
				<input type="text" name="class" value="<?php echo $data[7]; ?>"/>
			</td>
			<td>
				(8).Type of body
			</td>
			<td>
				<input type="text" name="body" value="<?php echo $data[8]; ?>"/>
			</td>
		</tr>
		
		<tr>
			<td>
				<p style="font-style: arial;">(9).The Motor vehicle is</p>
			</td>
		</tr>
		<tr>
			<td>
				(a).a new vehicle
			</td>
			<td>
				<input type="text" name="newvehicle" value="<?php echo $data[9]; ?>"/>
			</td>
				<td>
				(10).Tyle of vehicle
			</td>
			<td>
				<input type="text" name="typeofvehicle" value="<?php echo $data[10]; ?>"/>
			</td>
		</tr>
		<tr>
			<td>
				(b).Ex-army vehicle
			</td>
			<td>
				<input type="text" name="exarmy1" value="<?php echo $data[11]; ?>"/>
			</td>
			<td>
				(11).Makers Name
			</td>
			<td>
				<input type="text" name="makersname" value="<?php echo $data[12]; ?>"/>
			</td>
		</tr>
		<tr>
			<td>
				(c).imported vehicle
			</td>
			<td>
				<input type="text" name="imported" value="<?php echo $data[13]; ?>"/>
			</td>
			<td>
				(12).Month and year of manufacturer
			</td>
			<td>
				<input type="text" name="monthyear" value="<?php echo $data[14]; ?>"/>
			</td>
		</tr>
		
		
		<tr>
			<td>
				(13).Number of cylinders
			</td>
			<td>
				<input type="text" name="cylinders" value="<?php echo $data[15]; ?>"/>
			</td>
			<td>
				(14).Horse power
			</td>
			<td>
				<input type="text" name="horsepower" value="<?php echo $data[16]; ?>"/>
			</td>
		</tr>
		
		<tr>
			<td>
				(15).Cubic capacity
			</td>
			<td>
				<input type="text" name="cubic" value="<?php echo $data[17]; ?>"/>
			</td>
			<td>
				(16).Maker's classification or if not known,
			</td>
			<td>
				<input type="text" name="makersclassi" value="<?php echo $data[18]; ?>"/>
			</td>
		</tr>
		
		<tr>
			<td>
				(17).Wheel base
			</td>
			<td>
				<input type="text" name="wheelbase" value="<?php echo $data[19]; ?>"/>
			</td>
			<td>
				(18).Chassis No. (Affix Pencil print)
			</td>
			<td>
				<input type="text" name="chassis" value="<?php echo $data[20]; ?>"/>
			</td>
		</tr>
		
		<tr>
			<td>
				(19).Seating capacity (including driver)
			</td>
			<td>
				<input type="text" name="seating" value="<?php echo $data[21]; ?>"/>
			</td>
			<td>
				(20).Fuel used in the engine
			</td>
			<td>
				<input type="text" name="fuel" value="<?php echo $data[22]; ?>"/>
			</td>
		</tr>
		
		<tr>
			<td>
				(21).Unladen weight
			</td>
			<td>
				<input type="text" name="unladenweighta" value="<?php echo $data[23]; ?>"/>
			</td>
			<td>
				(22).Particulars of previous registration and registered number
			</td>
			<td>
				<input type="text" name="previousnumber" value="<?php echo $data[24]; ?>"/>
			</td>
		</tr>
		
		<tr>
			<td>
				(23).Colour or colour of body
			</td>
			<td>
				<input type="text" name="color" value="<?php echo $data[25]; ?>"/>
			</td>
			<td>
				(24).Type of body
			</td>
			<td>
				<input type="text" name="typeofbody" value="<?php echo $data[26]; ?>"/>
			</td>
		</tr>
		
		<tr>
			<td>
				(25).Number, description and size of tyres
			</td>
			<td>
				
			</td>
			<td>
				(26).Maximum axle weight
			</td>
			
		</tr>
		
		<tr>
			<td>
				(a) Front axle
			</td>
			<td>
				<input type="text" name="frontaxle" value="<?php echo $data[27]; ?>"/>
			</td>
			<td>
				(a) Front axle
			</td>
			<td>
				<input type="text" name="wfrontaxle" value="<?php echo $data[28]; ?>"/>
			</td>
			
		</tr>
		<tr>
			<td>
				(b) Rear axle
			</td>
			<td>
				<input type="text" name="rearaxle" value="<?php echo $data[29]; ?>"/>
			</td>
			<td>
				(b) Rear axle
			</td>
			<td>
				<input type="text" name="wrearaxle" value="<?php echo $data[30]; ?>"/>
			</td>
			
		</tr>
		
		<tr>
			<td>
				(c) Any other axle
			</td>
			<td>
				<input type="text" name="otheraxle" value="<?php echo $data[31]; ?>"/>
			</td>
			<td>
				(c) Any other axle
			</td>
			<td>
				<input type="text" name="wotheraxle" value="<?php echo $data[32]; ?>"/>
			</td>
			
		</tr>
		<tr>
			<td>
				(d) Tandem axle
			</td>
			<td>
				<input type="text" name="tandomaxle" value="<?php echo $data[33]; ?>"/>
			</td>
			<td>
				(d) Tandem axle
			</td>
			<td>
				<input type="text" name="wtandomaxle" value="<?php echo $data[34]; ?>"/>
			</td>
			
		</tr>
		
		<tr>
			<td>
				(27).Gross vehicle weight
			</td>
			<td>
				
			</td>
			</tr>
			<tr>
			<td>
				(a) As certified by the manufacture
			</td>
			<td>
				<input type="text" name="certified" value="<?php echo $data[35]; ?>"/>Kgms
			</td>
			<td>
				(b) To be registered
			</td>
			<td>
				<input type="text" name="toberegistered" value="<?php echo $data[36]; ?>"/>Kgms
			</td>
			
		</tr>
		
		<tr>
			<td>
				(28).Overall
			</td>
			<td>
				
			</td>
		</tr>
		<tr>
			<td>
				(a) Overall length
			</td>
			<td>
				<input type="text" name="overalllength"value="<?php echo $data[37]; ?>"/>
			</td>
			<td>
				(b) Overall width
			</td>
			<td>
				<input type="text" name="overallweight" value="<?php echo $data[38]; ?>"/>
			</td>
		</tr>
		
		<tr>
			<td>
				(c) Overall height
			</td>
			<td>
				<input type="text" name="overallheight" value="<?php echo $data[39]; ?>"/>
			</td>
			<td>
				(d) Over hang
			</td>
			<td>
				<input type="text" name="overallhang" value="<?php echo $data[40]; ?>"/>
			</td>
		</tr>
		
		<tr>
			<td>
				(29).Number, description and size of tyres on each axle
			</td>
			<td>
				<input type="text" name="eachaxle" value="<?php echo $data[41]; ?>"/>
			</td>
			<td>
				(30).Maximum axle weight in respect of each 
			</td>
			<td>
				<input type="text" name="maximumaxle" value="<?php echo $data[42]; ?>"/>
			</td>
		</tr>
		
		
		<tr>
			<td>
				(31).Insurance certificate company
			</td>
			<td>
				<input type="text" name="insurance" value="<?php echo $data[43]; ?>"/>
			</td>
			<td>
				(32).The vehicle is exempted from Insurance.
			</td>
			<td>
				<input type="text" name="exempted" value="<?php echo $data[44]; ?>"/>
			</td>
		</tr>
		
		<tr>
			<td>
				(33).I have paid the prescribed fee of rupees
			</td>
			<td>
				<input type="text" name="prescribed" value="<?php echo $data[45]; ?>"/>
			</td>
			
		</tr>
		
		<tr>
			<td>
				
			</td>
			<td>
				
			</td>
			
		</tr>
		
		
		<tr>
			<td>
				
			</td>
			<td>
				<input type="submit" name="submit" value="Next Form" style="background-color: #f14d0e;color: #fff;"/>
				
			</td>
			
		</tr>
	</table>
  </form>
  <?php	
  }
 ?>

   </div>
 </div>
   
</body>
</html>
