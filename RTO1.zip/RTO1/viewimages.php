<?php
session_start();//session start
$uname="";$user_id="";
if(isset($_SESSION['adminname']))
	{
		$user_id= $_SESSION['admin_id'];
		$uname ="Welcome to "."". $_SESSION['adminname'];
		
	}
	else{
		header('Location:index.php');
	}
	
	?>
	<?php
	include('db.php');
	  $reurl="approval_process.php";$buttion_name="Approval";$status='';
	
	  $sid=$_POST['sid'];
	  
	  $sql="select status from buyer_info where bid='$sid'";
	  $res=mysql_query($sql);
 while($data=mysql_fetch_row($res))
 {
	  	$status=$data[0];
		
	  }
	  if($status=='Approved')
	  {
	  	   $reurl='regdetails.php';$buttion_name="Ok";
	  }
	  
	  
	?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title>ONLINE VEHICLE REGISTRATION SYSTEM</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width">
        <link href="css/style1.css" rel="stylesheet" type="text/css" />
		<link rel="stylesheet" href="css/sliding.css" type="text/css" media="screen" />
        <link rel="shortcut icon" href="./images/pwsicon.png">
		
     <script type="text/javascript">


function changeHashOnLoad() {
    window.location.href += "#";
    setTimeout("changeHashAgain()", "50"); 
}

function changeHashAgain() {
 window.location.href += "1";
}

var storedHash = window.location.hash;
window.setInterval(function () {
   if (window.location.hash != storedHash) {
        window.location.hash = storedHash;
   }
}, 50);

</script>

    </head>
<body>
   <div class="wrapper">
       <img width="960" src="images/rtohead.png" alt=""/>
	   <div class="menu">
     <ul class="blue">
	<li><a href="adminhome.php" title="Home"><span>Home</span></a></li>
	<li><a href="userdetails.php" title="Registered Details" ><span>User Details</span></a></li>
	<li><a href="regdetails.php" title="Registered Details" class="current" ><span>Registered Details</span></a></li>
     <li><a href="rto.php" title="RTO"  ><span>RTO</span></a></li>
  
	
   
	<li><font color="#f9600d"> <?php echo $uname; ?></font></li>
	<li><a href="logout.php">Logout</a></li>
</ul>
</div>
  <div class="clear">
  </div>


   
 <div class="content">
 
 </ul>
 <h3 align="center">Images</h3>
<ul>
<?php 
include('db.php');
$sid=$_POST['sid'];
$bid=$_POST['bid'];
$sql = "SELECT image1 FROM upload_images WHERE buyer_id='$bid'";
$result = mysql_query("$sql") or die("<b>Error:</b> Problem on Retrieving Image BLOB<br/>" . mysql_error());
$row = mysql_fetch_array($result);

header('Content-type: image/jpeg');
echo $row['image1'];
 ?>
 </div>
  <form action="<?php echo $reurl; ?>" method="POST">
  	<table>
	<input type="hidden" name="sid"  value="<?php echo $sid; ?>" />
		<tr>
			<td>
				
			</td>
			<td>
				<input type="submit" name="submit" value="<?php echo $buttion_name; ?>" style="margin-left: 400px; width:200px;height: 30px;background-color: #f14d0e;color: #fff;"/>
			
			</td>
		</tr>
	</table>
  </form>
  
   



   </div>
  

   
</body>
</html>
