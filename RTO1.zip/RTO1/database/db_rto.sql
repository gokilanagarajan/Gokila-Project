/*
SQLyog - Free MySQL GUI v5.19
Host - 5.5.16 : Database - onlinevehicleregistration
*********************************************************************
Server version : 5.5.16
*/


SET NAMES utf8;

SET SQL_MODE='';

create database if not exists `onlinevehicleregistration`;

USE `onlinevehicleregistration`;

SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO';

/*Table structure for table `buyer_info` */

DROP TABLE IF EXISTS `buyer_info`;

CREATE TABLE `buyer_info` (
  `bid` int(11) NOT NULL AUTO_INCREMENT,
  `date` varchar(20) DEFAULT NULL,
  `buyer_name` varchar(50) DEFAULT NULL,
  `buyer_dob` varchar(30) DEFAULT NULL,
  `contact_no` varchar(20) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `status` varchar(10) DEFAULT NULL,
  `bike_no` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`bid`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

/*Data for the table `buyer_info` */

insert into `buyer_info` (`bid`,`date`,`buyer_name`,`buyer_dob`,`contact_no`,`user_id`,`status`,`bike_no`) values (3,'2014-08-07','baskar','1987-11-02','9003620888',2,'Approved','0702'),(4,'2014-08-11','sdsdsd','2014-08-05','9876543215',2,'Approved',''),(8,'2014-08-27','Venkat','2014-08-06','9677522149',2,'Approved',NULL),(9,'2014-09-01','sekar','2003-12-28','8883388873',1,'Approved','0302'),(10,'2014-09-01','hgfhf','2014-09-02','8883388873',1,'Waiting',NULL),(11,'2014-09-08','Baskar','2014-01-01','9003620888',3,'Approved','0001'),(12,'2014-09-23','Venkat','2014-09-02','9003620888',3,'Approved',NULL),(13,'2015-03-19','b','2015-03-19','b',1,'Waiting',NULL);

/*Table structure for table `form20` */

DROP TABLE IF EXISTS `form20`;

CREATE TABLE `form20` (
  `f1id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  `age` varchar(30) DEFAULT NULL,
  `permanent` varchar(100) DEFAULT NULL,
  `temp` varchar(50) DEFAULT NULL,
  `manufacturer` varchar(100) DEFAULT NULL,
  `exarmy` varchar(20) DEFAULT NULL,
  `class` varchar(20) DEFAULT NULL,
  `body` varchar(100) DEFAULT NULL,
  `newvehicle` varchar(50) DEFAULT NULL,
  `typeofvehicle` varchar(30) DEFAULT NULL,
  `exarmy1` varchar(30) DEFAULT NULL,
  `makersname` varchar(30) DEFAULT NULL,
  `imported` varchar(30) DEFAULT NULL,
  `monthyear` varchar(30) DEFAULT NULL,
  `cylinders` varchar(30) DEFAULT NULL,
  `horsepower` varchar(30) DEFAULT NULL,
  `cubic` varchar(30) DEFAULT NULL,
  `makersclassi` varchar(30) DEFAULT NULL,
  `wheelbase` varchar(30) DEFAULT NULL,
  `chassis` varchar(30) DEFAULT NULL,
  `seating` varchar(30) DEFAULT NULL,
  `fuel` varchar(30) DEFAULT NULL,
  `unladenweighta` varchar(30) DEFAULT NULL,
  `previousnumber` varchar(30) DEFAULT NULL,
  `color` varchar(30) DEFAULT NULL,
  `typeofbody` varchar(30) DEFAULT NULL,
  `frontaxle` varchar(30) DEFAULT NULL,
  `wfrontaxle` varchar(30) DEFAULT NULL,
  `rearaxle` varchar(30) DEFAULT NULL,
  `wrearaxle` varchar(30) DEFAULT NULL,
  `otheraxle` varchar(30) DEFAULT NULL,
  `wotheraxle` varchar(30) DEFAULT NULL,
  `tandomaxle` varchar(30) DEFAULT NULL,
  `wtandomaxle` varchar(30) DEFAULT NULL,
  `certified` varchar(30) DEFAULT NULL,
  `toberegistered` varchar(30) DEFAULT NULL,
  `overalllength` varchar(30) DEFAULT NULL,
  `overallweight` varchar(30) DEFAULT NULL,
  `overallheight` varchar(30) DEFAULT NULL,
  `overallhang` varchar(30) DEFAULT NULL,
  `eachaxle` varchar(30) DEFAULT NULL,
  `maximumaxle` varchar(30) DEFAULT NULL,
  `insurance` varchar(30) DEFAULT NULL,
  `exempted` varchar(30) DEFAULT NULL,
  `prescribed` varchar(30) DEFAULT NULL,
  `user_id` int(5) DEFAULT NULL,
  `buyer_id` int(5) DEFAULT NULL,
  PRIMARY KEY (`f1id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

/*Data for the table `form20` */

insert into `form20` (`f1id`,`name`,`age`,`permanent`,`temp`,`manufacturer`,`exarmy`,`class`,`body`,`newvehicle`,`typeofvehicle`,`exarmy1`,`makersname`,`imported`,`monthyear`,`cylinders`,`horsepower`,`cubic`,`makersclassi`,`wheelbase`,`chassis`,`seating`,`fuel`,`unladenweighta`,`previousnumber`,`color`,`typeofbody`,`frontaxle`,`wfrontaxle`,`rearaxle`,`wrearaxle`,`otheraxle`,`wotheraxle`,`tandomaxle`,`wtandomaxle`,`certified`,`toberegistered`,`overalllength`,`overallweight`,`overallheight`,`overallhang`,`eachaxle`,`maximumaxle`,`insurance`,`exempted`,`prescribed`,`user_id`,`buyer_id`) values (3,'p','p','p','p','p','p','p','p','p','p','p','p','p','p','p','p','p','p','p','p','p','p','p','p','p','p','p','p','p','p','p','p','p','p','p','p','p','p','p','p','p','','p','p','p',1,2),(4,'baskar','23','chettipatty,omalur,salem','chettipatty,omalur,salem','Bangalore','no','hero','smart','hero','yes','sdfsd','dfs','sdfsd','qsdf','dsfs','sdf','dfsf','dgsdfg','gsde','gdgwe','dgs','gedgs','sdgfdsre','gdsg','sdgsd','dgsedf','dgsd','sdfs','gsdf','gdsg','gsdfg','gsdfs','dgsd','gdsgs','qgfsdgf','dgss','gdsfg','gdsg','gsdg','gdsgsw','dfwe','dfwe','dsfs','sd','sdvxcz',2,3),(5,'Venkat','23','g','gg','g','g','g','g','g','g','g','g','g','g','g','g','g','g','g','g','g','g','g','g','g','g','g','g','g','g','g','g','g','g','g','g','g','g','g','g','g','g','g','g','g',2,8),(6,'sekar','23','adadadad\r\nad\r\nasd\r\nasd','aadadasd\r\nadsadas\r\nd','asdasd','add','ss','sdsd','jlkj','kjlkjlk','jlkjlk','jlkjlk','jlkjlkj','lkjlkj','lkjlkj','lkjlkjl','kjlkjlkj','kljlkj','lkjlkj','lkjlkj','ljlkjl','jlkjlkj','lkjlkjl','kjlkjlk','jlkjlj','lkjlkj','lkjlkj','lkjlkjl','jlklj','lkjlkjl','kjlkjlk','jlkjlkj','lkjlkjl','kjlkjlk','jlkjlk','jlkjlk','jlkjlk','jlkjl','jlkjlk','jlkjlk','jlkjlkj','lkjlkj','ljlkj','lkjlk','jlkjl',1,9),(7,'hgfhf','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','',1,10),(8,'Baskar','23','Omalur,Salem','-','Hero','imported vehicle','hero','smart','hero','hero honda','No','Hero Pvt Ltd','Cheenai','2013','2','Yes','yes','No','yes','2546','Yes','yes','200','236','Black','Black','Yes','yes','yes','yes','yes','yes','yes','yes','24','54','5.5','6.5','5.5','5.5','54','54','North Insurance company','','470000',3,11),(9,'Venkat','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','',3,12),(10,'b','d','d','d','d','d','d','d','d','d','d','d','d','dd','d','','dd','d','d','d','d','d','d','d','d','d','d','d','dd','d','d','dd','d','d','d','d','d','d','d','d','d','d','d','d','d',1,13);

/*Table structure for table `form21` */

DROP TABLE IF EXISTS `form21`;

CREATE TABLE `form21` (
  `f2id` int(11) NOT NULL AUTO_INCREMENT,
  `brandname` varchar(50) DEFAULT NULL,
  `deliveredto` varchar(30) DEFAULT NULL,
  `delivereddate` varchar(50) DEFAULT NULL,
  `buyer` varchar(50) DEFAULT NULL,
  `guardian` varchar(50) DEFAULT NULL,
  `agreement` varchar(50) DEFAULT NULL,
  `permaddress` varchar(100) DEFAULT NULL,
  `tempaddress` varchar(100) DEFAULT NULL,
  `classvehicle` varchar(50) DEFAULT NULL,
  `makersname` varchar(30) DEFAULT NULL,
  `chasisno` varchar(30) DEFAULT NULL,
  `engineno` varchar(30) DEFAULT NULL,
  `cubiccapacity` varchar(30) DEFAULT NULL,
  `fuelused` varchar(30) DEFAULT NULL,
  `nocylinders` varchar(30) DEFAULT NULL,
  `manufacturer` varchar(30) DEFAULT NULL,
  `seating` varchar(30) DEFAULT NULL,
  `unladen` varchar(30) DEFAULT NULL,
  `frontaxle` varchar(30) DEFAULT NULL,
  `rearaxle` varchar(30) DEFAULT NULL,
  `otheraxle` varchar(30) DEFAULT NULL,
  `tandemaxle` varchar(30) DEFAULT NULL,
  `colors` varchar(30) DEFAULT NULL,
  `grossvehicle` varchar(30) DEFAULT NULL,
  `typeofbody` varchar(30) DEFAULT NULL,
  `user_id` int(5) DEFAULT NULL,
  `buyer_id` int(5) DEFAULT NULL,
  PRIMARY KEY (`f2id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

/*Data for the table `form21` */

insert into `form21` (`f2id`,`brandname`,`deliveredto`,`delivereddate`,`buyer`,`guardian`,`agreement`,`permaddress`,`tempaddress`,`classvehicle`,`makersname`,`chasisno`,`engineno`,`cubiccapacity`,`fuelused`,`nocylinders`,`manufacturer`,`seating`,`unladen`,`frontaxle`,`rearaxle`,`otheraxle`,`tandemaxle`,`colors`,`grossvehicle`,`typeofbody`,`user_id`,`buyer_id`) values (1,'F','h','h','h','h','h','h','h','h','h','h','h','h','h','h','h','h','h','h','h','h','h','h','h','h',1,2),(2,'hero','2014-12-31','2014-12-31','Baskar','manjula','purchase','omalur','omalur','hero','hero honda','23','34566','120','5','4','2014','2','56','43','yes','yes','yes','white and black','67','200',2,3),(4,'g','g','2014-08-27','Venkat','h','h','h','h','h','h','h','h','h','h','h','h','h','h','h','h','h','h','h','h','h',2,8),(5,'khkjh','kjhkjh','2014-09-10','sekar','lkjlkj','lkjlkj','lkjlkjl\r\njklhljl\r\nljkjlkj','lkjlkjjl\r\njljlkjlkjlkj]\r\njljlkjlkjjjjjjjjjlkj','jlkj','lkjlkj','lkj','lkjl','kjlk','jklj','klj','lkj','lk','jlk','jlk','j','lkj','klj','kl','j','klj',1,9),(6,'','','','hgfhf','','','','','','','','','','','','','','','','','','','','','',1,10),(7,'hero','Baskar','','Baskar','manjula','54','Omalur,Salem','Omalur,Salem','hero','hero honda','456','456','5','yes','yes','2013','yes','200','Yes','Yes','Yes','Yes','Yes','Yes','Hero',3,11),(8,'','','','Venkat','','','','','','','','','','','','','','','','','','','','','',3,12),(9,'fF','F','2015-03-19','b','F','g','g','g','g','g','g','g','g','g','g','g','g','g','g','g','g','g','g','g','g',1,13);

/*Table structure for table `l_admin` */

DROP TABLE IF EXISTS `l_admin`;

CREATE TABLE `l_admin` (
  `admin_id` varchar(5) NOT NULL,
  `username` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  `mailid` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`admin_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `l_admin` */

insert into `l_admin` (`admin_id`,`username`,`password`,`mailid`) values ('1','admin','admin','ddsdhana@gmail.com');

/*Table structure for table `l_rto_regist` */

DROP TABLE IF EXISTS `l_rto_regist`;

CREATE TABLE `l_rto_regist` (
  `rto_id` int(10) NOT NULL AUTO_INCREMENT,
  `reg_no` varchar(50) NOT NULL,
  `location` varchar(200) NOT NULL,
  `start` varchar(10) DEFAULT NULL,
  `uptono` varchar(20) DEFAULT '0',
  PRIMARY KEY (`rto_id`)
) ENGINE=InnoDB AUTO_INCREMENT=118 DEFAULT CHARSET=latin1;

/*Data for the table `l_rto_regist` */

insert into `l_rto_regist` (`rto_id`,`reg_no`,`location`,`start`,`uptono`) values (1,'TN01','CHENNAI(CENTRAL)','A','1000'),(2,'TN02','CHENNAI(NORTH-WEST)','A','0'),(3,'TN03','CHENNAI(NORTH-EAST)','A','0'),(4,'TN04','CHENNAI(EAST)','A','0'),(5,'TN05','CHENNAI(NORTH)','A','0'),(6,'TN06','CHENNAI(SOUTH-EAST)','A','0'),(7,'TN09','CHENNAI(WEST)','A','0'),(8,'TN10','CHENNAI(SOUTH-WEST)','A','0'),(9,'TN11','RTO TAMBARAM','A','1000'),(11,'TN16','RTO TINDIVANAM','A','0'),(12,'TN18','REDHILLS','A','0'),(13,'TN18Z','AMBATTUR','A','0'),(14,'TN19','CHENGALPATTU','A','0'),(15,'TN19Z','MADURANTAKAM','A','0'),(16,'TN20','TIRUVALLUR','A','0'),(17,'TN20Y','POONAMALLE','A','0'),(18,'TN21','KANCHEEPURAM','A','0'),(19,'TN21W','SRIPERUMBUDUR','A','0'),(20,'TN22','MEENAMBAKKAM','A','0'),(21,'TN23','VELLORE','A','0'),(22,'TN23T','GUDIYATHAM','A','0'),(23,'TN23Y','VANIYAMBADI','A','0'),(24,'TN24','KRISHNAGIRI','A','0'),(25,'TN25','TIRUVANNAMALAI','A','0'),(26,'TN25Z','ARANI','A','0'),(27,'TN28','NAMAKKAL','A','0'),(28,'TN28Y','PARAMATHIVELLORE','A','0'),(29,'TN28Z','RASIPURAM','A','0'),(30,'TN29','DHARMAPURI','A','0'),(31,'TN29W','PALACODE','A','0'),(32,'TN29Z','HARUR','A','0'),(33,'TN30','SALEM(WEST)','A','0'),(34,'TN30W','OMALUR','A','0'),(35,'TN31','CUDDALORE','A','0'),(36,'TN31U','CHIDAMBARAM','A','0'),(37,'TN31V','VIRUDHACHALAM','A','0'),(38,'TN31Y','NEYVELI','A','0'),(39,'TN32','VILLUPURAM','A','0'),(40,'TN32W','KALLAKURICHI','A','0'),(41,'TN32Z','ULUNDURPET','A','0'),(42,'TN33','ERODE','A','0'),(43,'TN34','TIRUCHENCODE','A','0'),(44,'TN36','GOBICHETTIPALAYAM','A','0'),(45,'TN36W','BHAVANI','A','0'),(46,'TN36Z','SATHIYAMANGALAM','A','0'),(47,'TN37','COIMBATORE(SOUTH)','A','0'),(48,'TN38','COIMBATORE(NORTH) ','A','0'),(49,'TN39','TIRUPPUR(NORTH)','A','0'),(50,'TN39Z','AVINASHI','A','0'),(51,'TN40','METTUPALAYAM','A','0'),(52,'TN41','POLLACHI','A','0'),(53,'TN42','TIRUPUR(SOUTH)','A','0'),(54,'TN42Y','KANGAYAM','A','0'),(55,'TN43','OOTY','A','0'),(56,'TN43Z','GUDALUR','A','0'),(57,'TN45','TRICHIRAPPALLI','A','0'),(58,'TN45Y','THIRUVERUMBUR','A','0'),(59,'TN45Z','MANAPPARAI','A','0'),(60,'TN46','PERAMBALUR','A','0'),(61,'TN47','KARUR','A','0'),(62,'TN47Z','KULITHALAI','A','0'),(63,'TN48','SRIRANGAM','A','0'),(64,'TN48Z','THURAIYUR','A','0'),(65,'TN49','THANJAVUR','A','0'),(66,'TN49Y','PATTUKOTTAI','A','0'),(67,'TN50','THIRUVARUR','A','0'),(68,'TN50Z','MANNARGUDI','A','0'),(69,'TN51','NAGAPATTINAM','A','0'),(70,'TN51Z','MAYILADURAI','A','0'),(71,'TN52','SANGARI','A','0'),(72,'TN52Z','METTUR','A','0'),(73,'TN54','SALEM(EAST)','A','1000'),(74,'TN55','PUDUKOTTAI','A','0'),(75,'TN55Z','ARANTHANGI','A','0'),(76,'TN56','PERUNDURAI','A','0'),(77,'TN57','DINDIGUL','A','0'),(78,'TN57R','OTTANCHATRAM','A','0'),(79,'TN57V','VADASANDUR','A','0'),(80,'TN57Y','BATALAGUNDU','A','0'),(81,'TN57Z','PALANI','A','0'),(82,'TN58','MADURAI(SOUTH)','A','0'),(83,'TN58Z','THIRUMANGALAM','A','0'),(84,'TN59','MADURAI(NORTH)','A','0'),(85,'TN59V','VADIPATTI','A','0'),(86,'TN59Z','MELUR','A','0'),(87,'TN60','THENI','A','0'),(88,'TN60Z','UTHAMAPALAYAM','A','0'),(89,'TN61','ARIYALUR','A','0'),(90,'TN63','SIVAGANGA','A','0'),(91,'TN63Z','KARAIKUDI','A','0'),(92,'TN64','MADURAI(South)','A','0'),(93,'TN65','RAMANATHPURAM','A','0'),(94,'TN65Z',' PARAMAKUDI','A','0'),(95,'TN66','COIMBATORE(CENTRAL)','A','0'),(96,'TN67','VIRUDHUNAGAR','A','0'),(97,'TN67U','SIVAKASI','A','0'),(98,'TN67Z','SRIVILIPUTHUR','A','0'),(99,'TN68','KUMBAKONAM','A','0'),(100,'TN69','TUTICORIN','A','0'),(101,'TN69Y','TIRUCHENDUR','A','0'),(102,'TN69Z','KOVILPATTI','A','0'),(103,'TN70','HOSUR','A','0'),(104,'TN72','TIRUNELVELI','A','0'),(105,'TN72V','VALLIOOR','A','0'),(106,'TN73','RANIPET','A','0'),(107,'TN73Z','ARAKONAM','A','0'),(108,'TN74','NAGERCOIL','A','0'),(109,'TN75','MARTHANDAM','A','0'),(110,'TN76','TENKASI','A','0'),(111,'TN76V','AMBASAMUTHIRAM','A','0'),(112,'TN76Z','SANKARANKOIL','A','0'),(113,'TN77','ATTUR','A','0'),(114,'TN77Z','VALAPADI','A','0'),(115,'TN78','DHARAPURAM','A','0'),(116,'TN78Z','UDUMALPET','A','0'),(117,'TN11Z','SOLLINGANALLUR','A','0');

/*Table structure for table `l_users` */

DROP TABLE IF EXISTS `l_users`;

CREATE TABLE `l_users` (
  `user_id` int(10) NOT NULL AUTO_INCREMENT,
  `showroom_name` varchar(300) DEFAULT NULL,
  `reg_no` varchar(50) DEFAULT NULL,
  `owner_name` varchar(100) DEFAULT NULL,
  `user_name` varchar(100) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `dob` varchar(50) DEFAULT NULL,
  `mail_id` varchar(100) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `mobile` varchar(50) DEFAULT NULL,
  `fax` varchar(50) DEFAULT NULL,
  `address` varchar(200) DEFAULT NULL,
  `rto` int(10) DEFAULT NULL,
  `active` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

/*Data for the table `l_users` */

insert into `l_users` (`user_id`,`showroom_name`,`reg_no`,`owner_name`,`user_name`,`password`,`dob`,`mail_id`,`phone`,`mobile`,`fax`,`address`,`rto`,`active`) values (1,'s','s','s','s','s','2014-08-06','s','s','s','s','s',1,'Active'),(2,'aabs infotech solutions','2345','Baskar','pgsbaskar','baskar','2014-08-07','pgsbaskar@gmail.com','0427-2446879','9003620888','0427-2446879','Omalur',1,'Active'),(3,'Venkat Agencies','OR12','Venkat','venkat','venkat','2014-02-20','venkat@gmail.com','02490-2258978','9003620888','0427-2446879','Salem,Tamilnadu',73,'Active');

/*Table structure for table `upload_images` */

DROP TABLE IF EXISTS `upload_images`;

CREATE TABLE `upload_images` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `image1` blob,
  `image2` blob,
  `image3` blob,
  `image4` blob,
  `image5` blob,
  `image6` blob,
  `image7` blob,
  `user_id` int(5) DEFAULT NULL,
  `buyer_id` int(5) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=latin1;

/*Data for the table `upload_images` */



SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
