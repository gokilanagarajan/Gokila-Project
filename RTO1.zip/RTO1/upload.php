<?php
session_start();//session start
$uname="sdf";$user_id="";$buyername="";$buyer_id="";$dobs="";
if(isset($_SESSION['username']))
	{
		$user_id= $_SESSION['user_id'];
		$uname ="Welcome to "."". $_SESSION['username'];
		
	}
	else{
		header('Location:index.php');
	}
	if(isset($_SESSION['buyername']))
	{
		$buyername= $_SESSION['buyername'];
		$dobs= $_SESSION['dobs'];
		include('db.php');
		$qu="select bid from buyer_info where buyer_name='$buyername' and buyer_dob='$dobs'";
		$re=mysql_query($qu);
		while($data=mysql_fetch_row($re))
		{
			$buyer_id=$data[0];
		}
		
	}
	?>
	<?php
if(isset($_FILES['files1'])){
	/* $errors= array();
	foreach($_FILES['files']['tmp_name'] as $key => $tmp_name ){
		$file_name = addslashes(file_get_contents($_FILES['files']['tmp_name'][$key]));
		$image_name = addslashes( $_FILES['files']['name'][$key]);
		$file_size =$_FILES['files']['size'][$key];
		$file_tmp =$_FILES['files']['tmp_name'][$key];
		$file_type=$_FILES['files']['type'][$key];	
        if($file_size > 2097152){
			$errors[]='File size must be less than 2 MB';
        }
		*/
		include('db.php');
		
		$image1 = addslashes(file_get_contents($_FILES['files1']['tmp_name'])); //SQL Injection defence!
        $image2 = addslashes(file_get_contents($_FILES['files2']['tmp_name'])); //SQL Injection defence!
        $image3 = addslashes(file_get_contents($_FILES['files3']['tmp_name'])); //SQL Injection defence!
		$image4 = addslashes(file_get_contents($_FILES['files4']['tmp_name'])); //SQL Injection defence!
		$image5 = addslashes(file_get_contents($_FILES['files5']['tmp_name'])); //SQL Injection defence!
		$image6 = addslashes(file_get_contents($_FILES['files6']['tmp_name'])); //SQL Injection defence!
		$image7 = addslashes(file_get_contents($_FILES['files7']['tmp_name'])); //SQL Injection defence!
       
       
		$user_id=$_POST['user_id'];
		$buyer_id=$_POST['buyer_id'];
		$sql = "INSERT INTO upload_images (image1,image2,image3,image4,image5,image6,image7,`user_id`,`buyer_id`) VALUES ('$image1','$image2','$image3','$image4','$image5','$image6','$image7','$user_id','$buyer_id')";
		$res=mysql_query($sql);
        if (!$res) { // Error handling
        echo '<script language="javascript">alert("Not");location.href=\'' . $_SERVER['HTTP_REFERER'] . '\'</script>';
      }
	  else{
	  	 echo '<script language="javascript">alert("Upload Successfully");location.href=\'' . $_SERVER['HTTP_REFERER'] . '\'</script>';
	  }
		
			
	}
	?>
	

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title>ONLINE VEHICLE REGISTRATION SYSTEM</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width">
        <link href="css/style1.css" rel="stylesheet" type="text/css" />
		<link rel="stylesheet" href="css/sliding.css" type="text/css" media="screen" />
        <link rel="shortcut icon" href="./images/pwsicon.png">
     <script type="text/javascript">


function changeHashOnLoad() {
    window.location.href += "#";
    setTimeout("changeHashAgain()", "50"); 
}

function changeHashAgain() {
 window.location.href += "1";
}

var storedHash = window.location.hash;
window.setInterval(function () {
   if (window.location.hash != storedHash) {
        window.location.hash = storedHash;
   }
}, 50);

</script>

    </head>
<body onload="changeHashOnLoad();">
   <div class="wrapper">
       <img width="960" src="images/rtohead.png" alt=""/>
	   <div class="menu">
     <ul class="blue">
	<li><a href="userhome.php" title="Home"><span>Home</span></a></li>
	<li><a href="registerdetails.php" title="Registered Details" class="current" ><span>Registered Details</span></a></li>
    <li><a href="newregister.php" title="New Registration" ><span>New Registration</span></a></li>
    <li><a href="useravailableno.php" title="Vehicle Number"><span>Vehicle Numbers</span></a></li>
	
     <li><a href="contact.php" title="Contact" ><span>Contact</span></a></li>
	<li><?php echo $uname; ?></li>
	<li><a href="logout.php">Logout</a></li>
</ul>
</div>
  <div class="clear">
  </div>
  
   
   
 <div class="content">
 
<br>
<h3>Upload Image</h3>
  <form action="" method="post" enctype="multipart/form-data">
  	<table>
	<input type="hidden" name="user_id" value="<?php echo $user_id; ?>"/>
	<input type="hidden" name="buyer_id" value="<?php echo $buyer_id; ?>"/>
		<tr>
			<td>
				Residential  certificate-1
			</td>
			<td>
				<input type="file" name="files1" required="true" multiple/>
			</td>
			
			
		</tr>
		<tr>
			<td>
				Residential  certificate-2
			</td>
			<td>
				<input type="file" name="files2"  required="true" multiple/>
			</td>
			
			
		</tr>
		<tr>
			<td>
				Insurance certificate
			</td>
			<td>
				<input type="file" name="files3"  required="true" multiple/>
			</td>
			
			
		</tr>
		<tr>
			<td>
				Self declaration certificate
			</td>
			<td>
				<input type="file" name="files4"  required="true" multiple/>
			</td>
			
			
		</tr>
		<tr>
			<td>
				Pan card
			</td>
			<td>
				<input type="file" name="files5"  required="true" multiple/>
			</td>
			
			
		</tr>
		<tr>
			<td>
				Photo
			</td>
			<td>
				<input type="file" name="files6"  required="true" multiple/>
			</td>
			
			
		</tr>
		<tr>
			<td>
				Noc form excersice department vehicle purchase from other state.
			</td>
			<td>
				<input type="file" name="files7"  required="true" multiple/>
			</td>
			
			
		</tr>
		
		
		<tr>
			<td>
				
			</td>
			<td>
				<input type="submit" name="submit" value="Upload"/>
				<input type="reset" name="Reset"/>
			</td>
			
		</tr>
	</table>
  </form>
   </div>
 </div>
   
</body>
</html>
