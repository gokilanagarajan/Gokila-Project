<?php 

include('db.php');
$name=$_POST['name'];
$age=$_POST['age'];
$permanent=$_POST['permanent'];
$temp=$_POST['temp'];
$manufacturer=$_POST['manufacturer'];
$exarmy=$_POST['exarmy'];
$class=$_POST['class'];
$body=$_POST['body'];
$newvehicle=$_POST['newvehicle'];
$typeofvehicle=$_POST['typeofvehicle'];
$exarmy1=$_POST['exarmy1'];
$makersname=$_POST['makersname'];
$imported=$_POST['imported'];
$monthyear=$_POST['monthyear'];
$cylinders=$_POST['cylinders'];
$horsepower=$_POST['horsepower'];
$cubic=$_POST['cubic'];
$makersclassi=$_POST['makersclassi'];
$wheelbase=$_POST['wheelbase'];
$chassis=$_POST['chassis'];
$seating=$_POST['seating'];
$fuel=$_POST['fuel'];
$unladenweighta=$_POST['unladenweighta'];
$previousnumber=$_POST['previousnumber'];
$color=$_POST['color'];
$typeofbody=$_POST['typeofbody'];
$frontaxle=$_POST['frontaxle'];
$wfrontaxle=$_POST['wfrontaxle'];
$rearaxle=$_POST['rearaxle'];
$wrearaxle=$_POST['wrearaxle'];
$otheraxle=$_POST['otheraxle'];
$wotheraxle=$_POST['wotheraxle'];
$tandomaxle=$_POST['tandomaxle'];
$wtandomaxle=$_POST['wtandomaxle'];
$certified=$_POST['certified'];
$toberegistered=$_POST['toberegistered'];
$overalllength=$_POST['overalllength'];
$overallweight=$_POST['overallweight'];
$overallheight=$_POST['overallheight'];
$overallhang=$_POST['overallhang'];
$eachaxle=$_POST['eachaxle'];
$maximumaxle=$_POST['maximumaxle'];
$insurance=$_POST['insurance'];
$exempted=$_POST['exempted'];
$prescribed=$_POST['prescribed'];
$user_id=$_POST['user_id'];
$buyer_id=$_POST['buyer_id'];

$sql="insert into form20(name,age,permanent,temp,manufacturer,exarmy,class,body,newvehicle,typeofvehicle,exarmy1,makersname,imported,monthyear,cylinders,horsepower,cubic,makersclassi,wheelbase,chassis,seating,fuel,unladenweighta,previousnumber,color,typeofbody,frontaxle,wfrontaxle,rearaxle,wrearaxle,otheraxle,wotheraxle,tandomaxle,wtandomaxle,certified,toberegistered,overalllength,overallweight,overallheight,overallhang,eachaxle,maximumaxle,insurance,exempted,prescribed,user_id,buyer_id)values('$name','$age','$permanent','$temp','$manufacturer','$exarmy','$class','$body','$newvehicle','$typeofvehicle','$exarmy1','$makersname','$imported','$monthyear','$cylinders','$horsepower','$cubic','$makersclassi','$wheelbase','$chassis','$seating','$fuel','$unladenweighta','$previousnumber','$color','$typeofbody','$frontaxle','$wfrontaxle','$rearaxle','$wrearaxle','$otheraxle','$wotheraxle','$tandomaxle','$wtandomaxle','$certified','$toberegistered','$overalllength','$overallweight','$overallheight','$overallhang','$eachaxle','$maximumaxle','$insurance','$exempted','$prescribed','$user_id','$buyer_id')";



$result=mysql_query($sql);
if($result)
{
	
	 $url="form21.php";
	 echo '<script language="javascript">alert("Form 20 Completed");location.href=\'' . $url . '\'</script>';
}
else
{
	 echo '<script language="javascript">alert("Please Try Again");location.href=\'' . $_SERVER['HTTP_REFERER'] . '\'</script>';
}

?>