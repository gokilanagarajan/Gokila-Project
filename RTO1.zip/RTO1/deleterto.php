<?php
  include('db.php');
  $did=$_GET['id'];
 
  $sql="delete from l_rto_regist where rto_id='$did' ";
  $res=mysql_query($sql);
  if($res)
  {
  	 echo '<script language="javascript">alert("Deleted");location.href=\'' . $_SERVER['HTTP_REFERER'] . '\'</script>';
  }
  {
  	 echo '<script language="javascript">alert("Please Try Again");location.href=\'' . $_SERVER['HTTP_REFERER'] . '\'</script>';
  }
?>