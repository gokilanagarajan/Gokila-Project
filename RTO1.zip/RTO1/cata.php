<?php
session_start();//session start
$uname="";$user_id="";
if(isset($_SESSION['username']))
	{
		$user_id= $_SESSION['user_id'];
		$uname ="Welcome to "."". $_SESSION['username'];
		
	}
	else{
		header('Location:index.php');
	}
	
	?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title>ONLINE VEHICLE REGISTRATION SYSTEM</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width">
        <link href="css/style1.css" rel="stylesheet" type="text/css" />
		<link rel="stylesheet" href="css/sliding.css" type="text/css" media="screen" />
        <link rel="shortcut icon" href="./images/pwsicon.png">
     <script type="text/javascript">


function changeHashOnLoad() {
    window.location.href += "#";
    setTimeout("changeHashAgain()", "50"); 
}

function changeHashAgain() {
 window.location.href += "1";
}

var storedHash = window.location.hash;
window.setInterval(function () {
   if (window.location.hash != storedHash) {
        window.location.hash = storedHash;
   }
}, 50);

</script>

    </head>
<body onload="changeHashOnLoad();">
   <div class="wrapper">
       <img width="960" src="images/rtohead.png" alt=""/>
	   <div class="menu">
     <ul class="blue">
	<li><a href="userhome.php" title="Home"><span>Home</span></a></li>
	<li><a href="registerdetails.php" title="Registered Details" class="current"><span>Registered Details</span></a></li>
   
    <li><a href="useravailableno.php" title="Vehicle Number"><span>Vehicle Numbers</span></a></li>
	
     <li><a href="contact.php" title="Contact" ><span>Contact</span></a></li>
	<li><font color="#f9600d"> <?php echo $uname; ?></font></li>
	<li><a href="logout.php">Logout</a></li>
</ul>
</div>
  <div class="clear">
  </div>
  
   
   
 <div class="content">
 <br>
 <?php 
  include('db.php');
  $bid=$_GET['id'];
  $sql="select rto from l_users where user_id=$user_id";
  $res=mysql_query($sql);
  while($data=mysql_fetch_row($res))
  {
  	$rtoid=$data[0];
	
  }
 ?>
  
  <form action="selectnumber.php" method="post">
  <input type="hidden" name="rtoid" value="<?php echo $rtoid; ?>" />
  <input type="hidden" name="bid" value="<?php echo $bid; ?>" />
  	<label>1).&nbsp;Select vehicle number generated from RTO (Not Payable)</label><br><br/>
	<input type="radio" name="cata" value="not-payable" />Not Payable<br/><br/>
	<label>2).&nbsp;Select Vehicle Number by their choice(payable)</label><br><br/>
	<input type="radio" name="cata" value="birth" />Date of birth<br/>
	<input type="radio" name="cata" value="purchase" />Date of purchase<br/>
	<input type="radio" name="cata" value="fancy" />fancy Numbers<br/><br/>
	<input type="submit" name="submit" value="Submit"/>
  </form>
  
   </div>
 </div>
   
</body>
</html>
