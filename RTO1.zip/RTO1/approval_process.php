<?php
include('db.php');
$sid=$_POST['sid'];
echo $sid;
$status="Approved";
$sql="update buyer_info set status='$status' where bid='$sid'";
$res=mysql_query($sql);
if($res)
{
	$url='regdetails.php';
	echo '<script language="javascript">alert("Apporval");location.href=\'' . $url . '\'</script>';
}
else{
	$url='regdetails.php';
	echo '<script language="javascript">alert("Please Try Again");location.href=\'' . $url . '\'</script>';
}
?>