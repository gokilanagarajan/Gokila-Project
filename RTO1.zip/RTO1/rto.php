<?php
session_start();//session start
$uname="";$user_id="";
if(isset($_SESSION['adminname']))
	{
		
		$uname ="Welcome to "."". $_SESSION['adminname'];
		
	}
	else{
		header('Location:index.php');
	}
	
	?>
	<?php
	
    if(isset($_POST['submit'])) {
		
		include('db.php');
		$sid=$_POST['statusid'];
		
		$status=$_POST['status'];
	
		$sql="update l_users set active='$status' where user_id='$sid'";
		$res=mysql_query($sql);
		if($res)
		{
		$url="userdetails.php";
	 echo '<script language="javascript">alert("Updated");location.href=\'' . $url . '\'</script>';	
		}
		else
		{
			
	 echo '<script language="javascript">alert("Please Try Again");location.href=\'' . $_SERVER['HTTP_REFERER'] . '\'</script>';
		}
	} 
	?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title>ONLINE VEHICLE REGISTRATION SYSTEM</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width">
        <link href="css/style1.css" rel="stylesheet" type="text/css" />
		<link rel="stylesheet" href="css/sliding.css" type="text/css" media="screen" />
        <link rel="shortcut icon" href="./images/pwsicon.png">
     <script type="text/javascript">


function changeHashOnLoad() {
    window.location.href += "#";
    setTimeout("changeHashAgain()", "50"); 
}

function changeHashAgain() {
 window.location.href += "1";
}

var storedHash = window.location.hash;
window.setInterval(function () {
   if (window.location.hash != storedHash) {
        window.location.hash = storedHash;
   }
}, 50);

</script>

  <script type="text/javascript" src="css/pagination.js">
  	
  </script>
  
    </head>
<body onload="changeHashOnLoad();">
   <div class="wrapper">
       <img width="960" src="images/rtohead.png" alt=""/>
	   <div class="menu">
    <ul class="blue">
	<li><a href="adminhome.php" title="Home"><span>Home</span></a></li>
	<li><a href="userdetails.php" title="Registered Details" ><span>User Details</span></a></li>
	<li><a href="regdetails.php" title="Registered Details" ><span>Registered Details</span></a></li>
    <li><a href="rto.php" title="RTO" class="current" ><span>RTO</span></a></li>
   
	<li><font color="#f9600d"> <?php echo $uname; ?></font></li>
	<li><a href="logout.php">Logout</a></li>
</ul>
</div>
  <div class="clear">
  </div>
  
   
   
 <div class="content">
 <br>
 <h3 align="center">RTO Office &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="addrto.php">Add Location</a></h3>
   
  <table align="center" border="2" id="results">
  <tr>
  	<th>Reg No</th>
	<th>Location</th>
	<th>Generate No</th>
	<th>View No</th>
	<th>Delete</th>
  </tr>
  <?php
  include('db.php');
  $query="select * from l_rto_regist";
  $result=mysql_query($query);
  while($data=mysql_fetch_row($result))
  {
  ?>
  <tr>
  <td><?php echo $data[1]; ?></td>
  <td><?php echo $data[2]; ?></td>
  
  <td><a href="generateno.php?id=<?php echo $data[0]; ?>">Generate</a></td>
  <td><a href="availableno.php?id=<?php echo $data[0]; ?>">Available No</a></td>
  <td><a href="deleterto.php?id=<?php echo $data[0]; ?>" onClick="return confirm('Do u Want to delete?')">Delete</a></td>
  
  <?php	
  }
  ?>
  </table>
 
<div id="pageNavPosition" style="position:absolute;top:570px;left:500px"></div>
<script type="text/javascript"><!--
        var pager = new Pager('results',10); 
        pager.init(); 
        pager.showPageNav('pager', 'pageNavPosition'); 
        pager.showPage(1);
    //--></script>
</div>

   </div>
 </div>
   
</body>
</html>
