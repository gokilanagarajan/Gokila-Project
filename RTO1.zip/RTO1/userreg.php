<?php
if(isset($_POST['submit'])) { 
include('db.php');
$roomname=$_POST['roomname'];
$regno=$_POST['regno'];
$ownername=$_POST['ownername'];
$username=$_POST['username'];
$password=$_POST['password'];
$dob=$_POST['dob'];
$mailid=$_POST['mailid'];
$phone=$_POST['phone'];
$mobile=$_POST['mobile'];
$fax=$_POST['fax'];
$address=$_POST['address'];
$rtooffice=$_POST['rtooffice'];
$active='DeActive';
$sql="insert into l_users(showroom_name,reg_no,owner_name,user_name,password,dob,mail_id,phone,mobile,fax,address,rto,active)values('$roomname','$regno','$ownername','$username','$password','$dob','$mailid','$phone','$mobile','$fax','$address','$rtooffice','$active')";
$res=mysql_query($sql);
if($res)
{
	 $url='index.php';
	 echo '<script language="javascript">alert("Register Successfully");location.href=\'' .$url. '\'</script>';
}
else
{
	 $url='userreg.php';
	 echo '<script language="javascript">alert("Please Try Again");location.href=\'' . $url . '\'</script>';
}
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title>ONLINE VEHICLE REGISTRATION SYSTEM</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width">
        <link href="css/style.css" rel="stylesheet" type="text/css" />
        <link rel="shortcut icon" href="./images/pwsicon.png">
     <script type="text/javascript">


function changeHashOnLoad() {
    window.location.href += "#";
    setTimeout("changeHashAgain()", "50"); 
}

function changeHashAgain() {
 window.location.href += "1";
}

var storedHash = window.location.hash;
window.setInterval(function () {
   if (window.location.hash != storedHash) {
        window.location.hash = storedHash;
   }
}, 50);

</script>

    </head>
<body>
<?php include('db.php'); ?>
   <div class="wrapper">
       <img width="960" src="images/rtohead.png" alt=""/>
     
   <div class="contleft">
   		
		
		
	.
		
		
		
		
   </div>
   
   <div class="contright">
   		 <div class="regbox">
              <h3 style="margin-left: 70px;margin-top: 20px; color: #98AFC7;">New User Registration </h3>
                  <form action="<?php echo htmlentities($_SERVER['PHP_SELF']); ?>" method="POST" >
                        <table style="margin-top: 8px; margin-left: 30px;">
              <tr>
                  <td>Show Room Name</td>
                  <td><input type="text" required="true" name="roomname"></input>  </td>
              </tr>
			  
			   <tr>
                  <td>Registration Number</td>
                  <td><input type="text" required="true" name="regno"></input>  </td>
              </tr>
              <tr>
                  <td>Owner Name</td>
                  <td><input type="text" required="true" name="ownername"></input>  </td>
              </tr>
            
			  <tr>
                  <td>User Name</td>
                  <td><input type="text" required="true" name="username"></input>  </td>
              </tr>
              <tr>
                  <td>Password</td>
                  <td><input type="password" required="true" name="password"></input>  </td>
              </tr>
             
              <tr>
                  <td>DOB</td>
                  <td><input type="date" required="true"  name="dob"></input>  </td>
                  
              </tr>
			    <tr>
                  <td>E-Mail Id</td>
                  <td><input type="text" required="true" name="mailid"></input>  </td>
              </tr>
			  
              <tr>
                  <td>Phone Number</td>
                  <td><input type="text"  required="true" name="phone"></input>  </td>
              </tr>
              <tr>
                  <td>Mobile Number</td>
                  <td><input type="text" required="true" name="mobile"></input>  </td>
              </tr>
			    <tr>
                  <td>Fax Number</td>
                  <td><input type="text" required="true" name="fax"></input>  </td>
              </tr>
			  
			   <tr>
                  <td>Address</td>
                  <td><textarea  name="address" rows="4" cols="17"></textarea> </td>
              </tr>
               <tr>
                  <td>Select RTO Office</td>
                  <td>
				  <select name="rtooffice">
				  <option value="0" >Select RTO Office</option>
				 <?php
					
					$sql=mysql_query("select rto_id,location from l_rto_regist");
					while($row=mysql_fetch_array($sql))
					{
					$id=$row['rto_id'];
					$data=$row['location'];
					echo '<option value="'.$id.'">'.$data.'</option>';
			     }?>
				  </select>
				  </td>
              </tr>
            
              <tr>
                  <td><img onclick="history.go(-1)"  alt="Back"/></td>
                  <td><input type="submit" name="submit" value="Commit"></input> 
                      <input type="reset" value="Reset"></input>  </td>
              </tr>
          </table>
          </form>
       </div>
   </div>
   </div> 
</body>
</html>
