<?php 

include('db.php');

$brandname=$_POST['brandname'];
$deliveredto=$_POST['deliveredto'];
$delivereddate=$_POST['delivereddate'];
$buyer=$_POST['buyer'];
$guardian=$_POST['guardian'];
$agreement=$_POST['agreement'];
$permaddress=$_POST['permaddress'];
$tempaddress=$_POST['tempaddress'];
$classvehicle=$_POST['classvehicle'];
$makersname=$_POST['makersname'];
$chasisno=$_POST['chasisno'];
$engineno=$_POST['engineno'];
$cubiccapacity=$_POST['cubiccapacity'];
$fuelused=$_POST['fuelused'];
$nocylinders=$_POST['nocylinders'];
$manufacturer=$_POST['manufacturer'];
$seating=$_POST['seating'];
$unladen=$_POST['unladen'];
$frontaxle=$_POST['frontaxle'];
$rearaxle=$_POST['rearaxle'];
$otheraxle=$_POST['otheraxle'];
$tandemaxle=$_POST['tandemaxle'];
$colors=$_POST['colors'];
$grossvehicle=$_POST['grossvehicle'];
$typeofbody=$_POST['typeofbody'];
$user_id=$_POST['user_id'];
$buyer_id=$_POST['buyer_id'];



$sql="insert into form21(brandname,deliveredto,delivereddate,buyer,guardian,agreement,permaddress,tempaddress,classvehicle,makersname,chasisno,engineno,cubiccapacity,fuelused,nocylinders,manufacturer,seating,unladen,frontaxle,rearaxle,otheraxle,tandemaxle,colors,grossvehicle,typeofbody,user_id,buyer_id)values('$brandname','$deliveredto','$delivereddate','$buyer','$guardian','$agreement','$permaddress','$tempaddress','$classvehicle','$makersname','$chasisno','$engineno','$cubiccapacity','$fuelused','$nocylinders','$manufacturer','$seating','$unladen','$frontaxle','$rearaxle','$otheraxle','$tandemaxle','$colors','$grossvehicle','$typeofbody','$user_id',$buyer_id)";

$result=mysql_query($sql);
if($result)
{
	 $url="upload.php";
	 echo '<script language="javascript">alert("Form 21 Completed");location.href=\'' . $url . '\'</script>';
}
else
{
	 echo '<script language="javascript">alert("Please Try Again");location.href=\'' . $_SERVER['HTTP_REFERER'] . '\'</script>';
}


?>