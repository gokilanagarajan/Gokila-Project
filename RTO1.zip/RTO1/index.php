<?php
ob_start();
session_start();
if(isset($_POST['submit'])) { 
include('db.php');
$uname=$_POST['uname'];
$pwd=$_POST['pwd'];
$query="select * from l_admin where username='$uname' and password='$pwd'";
$result=mysql_query($query);
if($data=mysql_fetch_row($result))
{
	 session_regenerate_id();
	 $_SESSION['admin_id']=$data[0];
     $_SESSION['adminname'] = $data[1];
	 session_write_close();
	 $url='adminhome.php';
	 echo '<script language="javascript">location.href=\'' . $url . '\'</script>';
}
else{
	$url='index.php';
    session_regenerate_id();
    $_SESSION['login_status'] ='Invalid User Name and Password';
    session_write_close();
			
    echo '<script language="javascript">alert("Invalid User Name and Password");location.href=\'' . $_SERVER['HTTP_REFERER'] . '\'</script>';
}
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title>ONLINE VEHICLE REGISTRATION SYSTEM</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width">
        <link href="css/style.css" rel="stylesheet" type="text/css" />
        <link rel="shortcut icon" href="./images/pwsicon.png">
     <script type="text/javascript">


function changeHashOnLoad() {
    window.location.href += "#";
    setTimeout("changeHashAgain()", "50"); 
}

function changeHashAgain() {
 window.location.href += "1";
}

var storedHash = window.location.hash;
window.setInterval(function () {
   if (window.location.hash != storedHash) {
        window.location.hash = storedHash;
   }
}, 50);

</script>

    </head>
<body onload="changeHashOnLoad();">
   <div class="wrapper">
       <img width="960" src="./images/rtohead.png" alt=""/>
     
   <div class="contleft">
   		
		
		
	<div class="clear"></div>
   <p style="text-align: center; margin-top:50px; margin-left:50px; ">
   
   		<img  src="images/slide004.png"/>
   </p>
   		
		
		
		
		
   </div>
   
   <div class="contright">
   		 <div class="loginbox">
              <h3 style="margin-left: 70px;margin-top: 20px; color: #98AFC7;">Login with Admin</h3>
                   <form action="<?php echo htmlentities($_SERVER['PHP_SELF']); ?>" method="POST" >
                        <table style="margin-left: 20px;">
                  <tr>
                      <td>User Name</td>
					 
                      <td><input type="text" name="uname"> </td>
                  </tr>
                  <tr>
                      <td>Password</td>
                      <td><input type="password" name="pwd"> </td>
                  </tr>
                   <tr>
                      <td></td>
                      <td><input style="width: 70px;" type="submit" name="submit" value="Login"/>
                          <input  style="width: 70px;" type="reset" value="Reset"/> </td>
                   </tr>
				   <tr>
						   <td></td>
						   <td><a href="./userlogin.php">Login with User</a></td>
				   </tr>
                 
              		</table>
                 </form>
       </div>
   </div>
   </div> 
</body>
</html>
