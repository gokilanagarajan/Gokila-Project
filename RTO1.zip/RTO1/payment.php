<?php
session_start();//session start
$uname="sdf";$user_id="";
if(isset($_SESSION['username']))
	{
		$user_id= $_SESSION['user_id'];
		$uname ="Welcome to "."". $_SESSION['username'];
		
	}
	else{
		header('Location:index.php');
	}
	
	?>
	<?php

if(isset($_POST['submit'])) {
	include('db.php');
	$bikeno=$_POST['bikeno'];
	$bid=$_POST['bid'];
	$sql="update buyer_info set bike_no='$bikeno' where bid=$bid";
	$res=mysql_query($sql);
	if($res)
	{
		 $url='registerdetails.php';
	 echo '<script language="javascript">alert("Amount Paid");location.href=\'' . $url . '\'</script>';
	}
	else
	{
		
	}
	}
	?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title>ONLINE VEHICLE REGISTRATION SYSTEM</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width">
        <link href="css/style1.css" rel="stylesheet" type="text/css" />
		<link rel="stylesheet" href="css/sliding.css" type="text/css" media="screen" />
        <link rel="shortcut icon" href="./images/pwsicon.png">
     

    </head>
<body >
   <div class="wrapper">
       <img width="960" src="images/rtohead.png" alt=""/>
	   <div class="menu">
     <ul class="blue">
	<li><a href="userhome.php" title="Home"><span>Home</span></a></li>
	<li><a href="registerdetails.php" title="Registered Details" class="current" ><span>Registered Details</span></a></li>
   
    <li><a href="useravailableno.php" title="Vehicle Number"><span>Vehicle Numbers</span></a></li>
	
     <li><a href="contact.php" title="Contact" ><span>Contact</span></a></li>
	<li><?php echo $uname; ?></li>
	<li><a href="logout.php">Logout</a></li>
</ul>
</div>
  <div class="clear">
  </div>
  
   
   
 <div class="content">
 <br>
 <?php
 
	$bid=$_GET['bid'];
	$bno=$_GET['no'];
 ?>
 <h3 style="margin-left: 250px; font-size: 40px;">Online Payment</h3>  
                                        <form method="post" action="<?php echo htmlentities($_SERVER['PHP_SELF']); ?>"> 
                                    <table style="margin-left: 250px; margin-top: 50px;" border="0">
									<input type="hidden" required="true" name="bid" value="<?php echo $bid; ?>">
									<tr>
                                            <td>
                                                Bike No
                                            </td>
                                            <td>
                                                <input type="text" required="true" name="bikeno" value="<?php echo $bno; ?>"></input>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>Your Bank is</td>
                                            <td>
                                                <select name="Bank">
                                                    <option>Axis Bank</option>
                                                    <option>IOB Bank</option>
                                                    <option>ICICI Bank</option>
                                                    <option>TMB Bank</option>
                                                    <option>State Bank</option>
                                                    <option>Indian Bank</option>
                                                    <option>HDFC Bank</option>
                                                    <option>KVB Bank</option>                                                    
                                                </select>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                Card Number
                                            </td>
                                            <td>
                                                <input type="text" required="true" name="cardno"></input>
                                            </td>
                                        </tr>
                                        <tr>
                                            
                                            <td>Payment Rs:</td>
                                            <td><input type="text" readonly name="amt" value="2000"></input></td>
                                        </tr>
                                        
                                        <tr>
                                            <td></td>
                                            <td>
                                                <input type="submit" name="submit" value="Submit"></input>
                                                <input type="button" value="Cancel" onclick="history.go(-1)"></input>
                                            </td>
                                        </tr>
                                                </table>
                                            </form>
   </div>
 </div>
   
</body>
</html>
