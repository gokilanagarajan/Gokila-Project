<?php
session_start();//session start
$uname="";$user_id="";
if(isset($_SESSION['adminname']))
	{
		$user_id= $_SESSION['admin_id'];
		$uname ="Welcome to "."". $_SESSION['adminname'];
		
	}
	else{
		header('Location:index.php');
	}
	
	?>


<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title>ONLINE VEHICLE REGISTRATION SYSTEM</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width">
        <link href="css/style1.css" rel="stylesheet" type="text/css" />
		<link rel="stylesheet" href="css/sliding.css" type="text/css" media="screen" />
        <link rel="shortcut icon" href="./images/pwsicon.png">
     <script type="text/javascript">


function changeHashOnLoad() {
    window.location.href += "#";
    setTimeout("changeHashAgain()", "50"); 
}

function changeHashAgain() {
 window.location.href += "1";
}

var storedHash = window.location.hash;
window.setInterval(function () {
   if (window.location.hash != storedHash) {
        window.location.hash = storedHash;
   }
}, 50);

</script>

    </head>
<body onload="changeHashOnLoad();">
   <div class="wrapper">
       <img width="960" src="images/rtohead.png" alt=""/>
	   <div class="menu">
     <ul class="blue">
	<li><a href="adminhome.php" title="Home"><span>Home</span></a></li>
	<li><a href="userdetails.php" title="Registered Details" ><span>User Details</span></a></li>
	<li><a href="regdetails.php" title="Registered Details" class="current" ><span>Registered Details</span></a></li>
    <li><a href="rto.php" title="RTO"><span>RTO</span></a></li>
  
	<li><font color="#f9600d"> <?php echo $uname; ?></font></li>
	<li><a href="logout.php">Logout</a></li>
</ul>
</div>
  <div class="clear">
  </div>
  
   
   
 <div class="content">
 <?php
 $bid=$_POST['bid'];
 $sid=$_POST['sid'];
 include('db.php');
 $sql="select * from form21 where buyer_id='$bid'";
 $res=mysql_query($sql);
 while($data=mysql_fetch_row($res))
 {
?>
 <h3 align="center">FORM 21</h3>

<h4 align="center">[See Rules 47(a) and (d)]</h4>
<h3 align="center" style="font-style: normal;">SALE CERTIFICATE</h3>
<p style="text-align: justify;">(To be issued by manufacturer/dealer or officer of Defense Department (in case of military auctioned vehicles) for presentation along with the application for registration of a motor vehicle).</p>
<br>
  <form action="form22.php" method="post">
  	<table>
	<input type="hidden" name="sid"  value="<?php echo $sid; ?>" />
	<input type="hidden" name="bid"  value="<?php echo $bid; ?>" />
		<tr>
			<td>
				(1).brand name of the vehicle
			</td>
			<td>
				<input type="text" name="brandname" value="<?php echo $data[1]; ?>"/>
			</td>
			<td>
				(2).Delivered to
			</td>
			<td>
				<input type="text" name="deliveredto" value="<?php echo $data[2]; ?>"/>
			</td>
		</tr>
		
		<tr>
			<td>
				(3).Delivered date
			</td>
			<td>
				<input type="text" name="delivereddate" value="<?php echo $data[3]; ?>"/>
			</td>
			<td>
				(4).Name of the buyer
			</td>
			<td>
				<input type="text" name="buyer" value="<?php echo $data[4]; ?>"/>
			</td>
			
		</tr>
		<tr>
			<td>
				(5).Son /wife/daughter
			</td>
			<td>
				<input type="text" name="guardian" value="<?php echo $data[5]; ?>"/>
			</td>
			
			<td>
				(6).The vehicle is held under agreement of hire-purchase/lease/hypothecation with
			</td>
			<td>
				<input type="text" name="agreement" value="<?php echo $data[6]; ?>"/>
			</td>
			
			
		</tr>
		
		<tr>
		<td>
				(7).Address (Permanent)
			</td>
			<td>
				<textarea rows="3" cols="30" name="permaddress" ><?php echo $data[7]; ?></textarea>
			</td>
			<td>
				(8).Address (Temporary)
			</td>
			<td>
				<textarea rows="3" cols="30" name="tempaddress" ><?php echo $data[8]; ?></textarea>
			</td>
			
		</tr>
		<tr>
			<td>The details of the vehicle are given below</td>
			<td></td>
		</tr>
		
		<tr>
			<td>
				<p style="font-style: arial;">(9).Class of Vehicle</p>
			</td>
	
			<td>
				<input type="text" name="classvehicle" value="<?php echo $data[9]; ?>"/>
			</td>
				<td>
				(10).Maker's name
			</td>
			<td>
				<input type="text" name="makersname" value="<?php echo $data[10]; ?>"/>
			</td>
		</tr>
		<tr>
			
			<td>
				(11).Chassis No.
			</td>
			<td>
				<input type="text" name="chasisno" value="<?php echo $data[11]; ?>"/>
			</td>
		</tr>
		<tr>
			
			<td>
				(12).Engine No.
			</td>
			<td>
				<input type="text" name="engineno" value="<?php echo $data[12]; ?>"/>
			</td>
		</tr>
		
		
		<tr>
			<td>
				(13).Horse power or cubic capacity
			</td>
			<td>
				<input type="text" name="cubiccapacity" value="<?php echo $data[13]; ?>"/>
			</td>
			<td>
				(14).Fuel used
			</td>
			<td>
				<input type="text" name="fuelused" value="<?php echo $data[14]; ?>"/>
			</td>
		</tr>
		
		<tr>
			<td>
				(15).Number of cylinders
			</td>
			<td>
				<input type="text" name="nocylinders" value="<?php echo $data[15]; ?>"/>
			</td>
			<td>
				(16).Month and year of manufacture
			</td>
			<td>
				<input type="text" name="manufacturer" value="<?php echo $data[16]; ?>"/>
			</td>
		</tr>
		
		<tr>
			<td>
				(17).Seating capacity(including driver)
			</td>
			<td>
				<input type="text" name="seating" value="<?php echo $data[17]; ?>"/>
			</td>
			<td>
				(18).Unladen Weight
			</td>
			<td>
				<input type="text" name="unladen" value="<?php echo $data[18]; ?>"/>
			</td>
		</tr>
		
		<tr>
			<td>
				(19).Maximum axle weight & number &
description of tyres (in case of transport vehicle
			</td>
			<td>
				
			</td>
			
		</tr>
		
		<tr>
			<td>
				(a) Front axle
			</td>
			<td>
				<input type="text" name="frontaxle" value="<?php echo $data[19]; ?>"/>
			</td>
			<td>
				(b) Rear axle
			</td>
			<td>
				<input type="text" name="rearaxle" value="<?php echo $data[20]; ?>"/>
			</td>
			
		</tr>
		<tr>
			<td>
				(c) Any other axle
			</td>
			<td>
				<input type="text" name="otheraxle" value="<?php echo $data[21]; ?>"/>
			</td>
			<td>
				(d) Tandem axle
			</td>
			<td>
				<input type="text" name="tandemaxle"  value="<?php echo $data[22]; ?>"/>
			</td>
			
		</tr>
		
		
		<tr>
			<td>
				(20). Colour or colours of the body
			</td>
			<td> 
				<input type="text" name="colors"  value="<?php echo $data[23]; ?>"/>
			</td>
			<td>
				(21).Gross vehicle weight
			</td>
			<td>
				<input type="text" name="grossvehicle"  value="<?php echo $data[24]; ?>"/>
			</td>
		</tr>
		
		<tr>
			<td>
				(22).Type of body
			</td>
			<td>
				<input type="text" name="typeofbody"  value="<?php echo $data[25]; ?>"/>
			</td>
			
		</tr>
		
		
		<tr>
			<td>
				
			</td>
			<td>
				<input type="submit" name="submit" value="Next Form"style="background-color: #f14d0e;color: #fff;"/>
			
			</td>
			
		</tr>
	</table>
  </form>
   <?php	
  }
 ?>
   </div>
 </div>
   
</body>
</html>
