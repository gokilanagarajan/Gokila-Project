<?php
ob_start();
session_start();
if(isset($_POST['submit'])) { 
include('db.php');
$uname=$_POST['uname'];

$pwd=$_POST['pwd'];
$status="";$user_id="";$username="";
$query="select * from l_users where user_name='$uname' and password='$pwd'";
$result=mysql_query($query);
while($data=mysql_fetch_row($result))
{
	  $status=$data[13];
	  $user_id = $data[0];
      $username = $data[3];
}
if($status=='Active')
{
	 session_regenerate_id();
     $_SESSION['user_id'] = $user_id;
     $_SESSION['username'] = $username;
	
	 session_write_close();
	 $url='userhome.php';
	 echo '<script language="javascript">location.href=\'' . $url . '\'</script>';
}
else{
	$url='index.php';
    session_regenerate_id();
    $_SESSION['login_status'] ='Invalid User Name and Password';
    session_write_close();
			
    echo '<script language="javascript">alert("Invalid User Name and Password");location.href=\'' . $_SERVER['HTTP_REFERER'] . '\'</script>';
}
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title>ONLINE VEHICLE REGISTRATION SYSTEM</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width">
        <link href="css/style.css" rel="stylesheet" type="text/css" />
        <link rel="shortcut icon" href="./images/pwsicon.png">
  

    </head>
<body>
   <div class="wrapper">
       <img width="960" src="images/rtohead.png" alt=""/>
     
   <div class="contleft">
   		
		
		
			
	<div class="clear"></div>
   <p style="text-align: center; margin-top:50px; margin-left:50px; ">
   
   		<img  src="images/slide_master_computer_hands1-474x342.jpg"/>
   </p>
   		
		
		
   </div>
   
   <div class="contright">
   		 <div class="loginbox">
              <h3 style="margin-left: 70px;margin-top: 20px; color: #98AFC7;">Login with User</h3>
                   <form action="<?php echo htmlentities($_SERVER['PHP_SELF']); ?>" method="POST" >
                        <table style="margin-left: 20px;">
                  <tr>
                      <td>User Name</td>
					 
                      <td><input type="text" name="uname"> </td>
                  </tr>
                  <tr>
                      <td>Password</td>
                      <td><input type="password" name="pwd"> </td>
                  </tr>
                  <tr>
                      <td></td>
                      <td><input style="width: 70px;" type="submit" name="submit" value="Login"/>
                          <input  style="width: 70px;" type="reset" value="Reset"/> </td>
                  </tr>
				   <tr>
						   <td><img onclick="history.go(-1)" alt="Back"/></td>
						   <td><a href="userreg.php">Sign for New User</a></td>
				   </tr>
                 
				 
              		</table>
                 </form>
       </div>
   </div>
   </div> 
</body>
</html>
