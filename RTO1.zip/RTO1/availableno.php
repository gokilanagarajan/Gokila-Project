<?php
session_start();//session start
$uname="";$user_id="";
if(isset($_SESSION['adminname']))
	{
		$user_id= $_SESSION['admin_id'];
		$uname ="Welcome to "."". $_SESSION['adminname'];
		
	}
	else{
		header('Location:index.php');
	}
	
	?>
	
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title>ONLINE VEHICLE REGISTRATION SYSTEM</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width">
        <link href="css/style1.css" rel="stylesheet" type="text/css" />
		<link rel="stylesheet" href="css/sliding.css" type="text/css" media="screen" />
        <link rel="shortcut icon" href="./images/pwsicon.png">
     <script type="text/javascript">


function changeHashOnLoad() {
    window.location.href += "#";
    setTimeout("changeHashAgain()", "50"); 
}

function changeHashAgain() {
 window.location.href += "1";
}

var storedHash = window.location.hash;
window.setInterval(function () {
   if (window.location.hash != storedHash) {
        window.location.hash = storedHash;
   }
}, 50);

</script>

  <script type="text/javascript" src="css/pagination.js">
  	
  </script>
  
    </head>
<body onload="changeHashOnLoad();">
   <div class="wrapper">
       <img width="960" src="images/rtohead.png" alt=""/>
	   <div class="menu">
     <ul class="blue">
	<li><a href="adminhome.php" title="Home"><span>Home</span></a></li>
	<li><a href="userdetails.php" title="Registered Details" ><span>User Details</span></a></li>
	<li><a href="regdetails.php" title="Registered Details"><span>Registered Details</span></a></li>
     <li><a href="rto.php" title="RTO"  class="current"   ><span>RTO</span></a></li>
  
	
   
	<li><font color="#f9600d"> <?php echo $uname; ?></font></li>
	<li><a href="logout.php">Logout</a></li>
</ul>
</div>
  <div class="clear">
  </div>
  

   
 <div class="content">
 <br>
 <h3 align="center">Available Numbers</h3>
   
  <ul>
  		
  <?php
  include('db.php');
  $rtoid=$_GET['id'];
  
  $uptono="";$x=0001;
  $arr = Array();
  $query="select * from l_rto_regist where rto_id=$rtoid";
  	$sql="select b.bike_no from l_users u,l_rto_regist l,buyer_info b where l.rto_id=$rtoid and l.rto_id=u.rto and u.user_id=b.user_id;";
  $result=mysql_query($query);
  while($data=mysql_fetch_row($result))
  {
  	$uptono=$data[4];
	for ($x; $x<=$uptono; $x++) {
	$tt=0;
		  $res=mysql_query($sql);
		  while($data1=mysql_fetch_row($res))
		  {
		  	$arr[]=$data1[0];
		}
		if (!in_array($x, $arr)) 
		{
				?>
  <li><a href=""> <?php printf("%04d", $x); ?></a></li>
  <?php 
		}
		
  }
  }
  ?>
  </ul>
  
  

</div>
</div>
</div>
   
</body>
</html>
