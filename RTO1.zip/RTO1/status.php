<?php
session_start();//session start
$uname="";$user_id="";
if(isset($_SESSION['adminname']))
	{
		$user_id= $_SESSION['admin_id'];
		$uname ="Welcome to "."". $_SESSION['adminname'];
		
	}
	else{
		header('Location:index.php');
	}
	
	?>
	<?php
	
    if(isset($_POST['submit'])) {
		
		include('db.php');
		$sid=$_POST['statusid'];
		
		$status=$_POST['status'];
	
		$sql="update l_users set active='$status' where user_id='$sid'";
		$res=mysql_query($sql);
		if($res)
		{
		$url="userdetails.php";
	 echo '<script language="javascript">alert("Updated");location.href=\'' . $url . '\'</script>';	
		}
		else
		{
			
	 echo '<script language="javascript">alert("Please Try Again");location.href=\'' . $_SERVER['HTTP_REFERER'] . '\'</script>';
		}
	} 
	?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title>ONLINE VEHICLE REGISTRATION SYSTEM</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width">
        <link href="css/style1.css" rel="stylesheet" type="text/css" />
		<link rel="stylesheet" href="css/sliding.css" type="text/css" media="screen" />
        <link rel="shortcut icon" href="./images/pwsicon.png">
     <script type="text/javascript">


function changeHashOnLoad() {
    window.location.href += "#";
    setTimeout("changeHashAgain()", "50"); 
}

function changeHashAgain() {
 window.location.href += "1";
}

var storedHash = window.location.hash;
window.setInterval(function () {
   if (window.location.hash != storedHash) {
        window.location.hash = storedHash;
   }
}, 50);

</script>

    </head>
<body onload="changeHashOnLoad();">
   <div class="wrapper">
       <img width="960" src="images/rtohead.png" alt=""/>
	   <div class="menu">
   <ul class="blue">
	<li><a href="adminhome.php" title="Home"><span>Home</span></a></li>
	<li><a href="userdetails.php" title="Registered Details" class="current"><span>User Details</span></a></li>
	<li><a href="regdetails.php" title="Registered Details" ><span>Registered Details</span></a></li>
    <li><a href="rto.php" title="RTO"><span>RTO</span></a></li>
   
	<li><font color="#f9600d"> <?php echo $uname; ?></font></li>
	<li><a href="logout.php">Logout</a></li>
</ul>
</div>
  <div class="clear">
  </div>
  
   
   
 <div class="content">
 <br>
 <h3 align="center">User Information</h3>
  <form action="<?php echo htmlentities($_SERVER['PHP_SELF']); ?>" method="POST" >
  <?php 
  include('db.php');
  $id=$_GET['id'];
  $query="select * from l_users where user_id='$id'";
  $result=mysql_query($query);
  while($data=mysql_fetch_row($result))
  {
  ?>
  
  <table align="center">
   <input type="hidden" name="statusid" value="<?php echo $id; ?>" />
  	<tr>
		<td>
			Show Room Name
		</td>
		<td>
			<input type="text" name="name" value="<?php echo $data[1]; ?>" required="true"/>
		</td>
	</tr>
	<tr>
		<td>
			Reg No
		</td>
		<td>
			<input type="text" name="reg_no" value="<?php echo $data[2]; ?>" required="true"/>
		</td>
	</tr>
	<tr>
		<td>
			Status
		</td>
		<td>
			<select name="status">
				<option value="<?php echo $data[13]; ?>"><?php echo $data[13]; ?></option>
				<option value="Active">Active</option>
				<option value="DeActive">DeActive</option>
			</select>
		</td>
	</tr>
	<tr>
		<td></td>
		<td></td>
	</tr>
	<tr>
		<td></td>
		<td><input type="submit" name="submit" value="Submit"/>
		<input type="reset" value="Reset"/></td>
	</tr>
  </table>
  <?php	
  }
  ?>	
  </form>
 
  
   </div>
 </div>
   
</body>
</html>
s