<?php
ob_start();
session_start();
$temp="";
$idvalue="";
$end="";
$result="";
$idvalue=$_GET['idvalue'];
$end=$_GET['end'];


  include('db.php');
  $query="select * from l_rto_regist where rto_id='$idvalue'";
  $result=mysql_query($query);
  $url="rto.php";
  while($data=mysql_fetch_row($result))
  {
  	$temp=$data[4];
	
  }

  if((int)$temp<(int)$end)
	{
	$sql="update l_rto_regist set uptono='$end' where rto_id='$idvalue' ";
	mysql_query($sql);
	
	 echo '<script language="javascript">
	 alert("Updated Successfully");
	 location.href=\'' . $url . '\'
	 </script>';
}
else
{
	 echo '<script language="javascript">
	 alert("Please Try Again");
	 location.href=\'' . $_SERVER['HTTP_REFERER'] . '\'
	 </script>';
}

?>