<?php
session_start();//session start
$uname="";$user_id="";
if(isset($_SESSION['adminname']))
	{
		$user_id= $_SESSION['admin_id'];
		$uname ="Welcome to "."". $_SESSION['adminname'];
		
	}
	else{
		header('Location:index.php');
	}
	
	?>
	<?php
	include('db.php');
	  $reurl="approval_process.php";$buttion_name="Approval";$status='';
	
	  $sid=$_POST['sid'];
	  
	  $sql="select status from buyer_info where bid='$sid'";
	  $res=mysql_query($sql);
 while($data=mysql_fetch_row($res))
 {
	  	$status=$data[0];
		
	  }
	  if($status=='Approved')
	  {
	  	   $reurl='regdetails.php';$buttion_name="Ok";
	  }
	  
	  
	?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title>ONLINE VEHICLE REGISTRATION SYSTEM</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width">
        <link href="css/style1.css" rel="stylesheet" type="text/css" />
		<link rel="stylesheet" href="css/sliding.css" type="text/css" media="screen" />
        <link rel="shortcut icon" href="./images/pwsicon.png">
		
     <script type="text/javascript">


function changeHashOnLoad() {
    window.location.href += "#";
    setTimeout("changeHashAgain()", "50"); 
}

function changeHashAgain() {
 window.location.href += "1";
}

var storedHash = window.location.hash;
window.setInterval(function () {
   if (window.location.hash != storedHash) {
        window.location.hash = storedHash;
   }
}, 50);

</script>

    </head>
<body onload="changeHashOnLoad();">
   <div class="wrapper">
       <img width="960" src="images/rtohead.png" alt=""/>
	   <div class="menu">
     <ul class="blue">
	<li><a href="adminhome.php" title="Home"><span>Home</span></a></li>
	<li><a href="userdetails.php" title="Registered Details" ><span>User Details</span></a></li>
	<li><a href="regdetails.php" title="Registered Details" ><span>Registered Details</span></a></li>
     <li><a href="rto.php" title="RTO" class="current" ><span>RTO</span></a></li>
  
	
   
	<li><font color="#f9600d"> <?php echo $uname; ?></font></li>
	<li><a href="logout.php">Logout</a></li>
</ul>
</div>
  <div class="clear">
  </div>
  
   
   
 <div class="content">
 
<?php 
$sid=$_POST['sid'];
$brandname=$_POST['brandname'];
$chasis=$_POST['chasisno'];
$engineno=$_POST['engineno'];
 $bid=$_POST['bid'];
 ?>
 <h3 align="center">FORM 22- A</h3>

<h4 align="center">[See Rules 47(g), 124, 126-A & 127]</h4>
<h3 align="center" style="font-style: normal;">INITIAL CERTIFICATE OF COMPLIANCE WITH POLLUTION</h3>
<h3 align="center" style="font-style: normal;">STANDARDS, SAFETY STANDARDS OF COMPONENTS AND ROAD</h3>
<h3 align="center" style="font-style: normal;">WORTHINESS</h3>
<h3 align="center" style="font-style: normal;">(FOR VEHICLES WHERE BODY IS FABRICATED SEPARATELY)</h3>
<br>
<h3 align="center" style="font-style: normal;">PART - I</h3>

<h3 align="center" style="font-style: normal;">(TO BE ISSUED BY THE MANUFACTURER)</h3>
<br>
<p style="text-align: justify; line-height:50px; font-family: times new roman; font-size: 22px; font-style: normal">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Certified that <font style="font-weight: bold;"><?php echo $brandname; ?></font> (brand name of the vehicle) bearing Chassis number <font style="font-weight: bold;"><?php echo $chasis; ?></font>. and Engine Number <font style="font-weight: bold;"><?php echo $engineno; ?></font>. Complied with the provisions of Motor Vehicles Act, 1988 and Rules made thereunder.</p>
<br>
<p style="text-align: right; line-height:50px; font-family: times new roman; font-size: 22px; font-style: normal">Signature of the Chassis Manufacturer</p>

<br>

<p style="text-align: justify; line-height:50px; font-family: times new roman; font-size: 22px; font-style: normal">Form 22-A, Part I shall be issued with the signature of the manufacturer duly printed in the Form itself by affixing facsimile signature in ink under the hand and seal of the manufacturer.</p>

<br>
<h3 align="center" style="font-style: normal;">PART - II</h3>

<h3 align="center" style="font-style: normal;">(TO BE ISSUED BY THE BODY BUILDER)</h3>
<br>

<p style="text-align: justify; line-height:50px; font-family: times new roman; font-size: 22px; font-style: normal">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Certified that body of the vehicle <font style="font-weight: bold;"><?php echo $brandname; ?></font> (brand name of the vehicle) bearing Chassis number <font style="font-weight: bold;"><?php echo $chasis; ?></font>. and Engine Number <font style="font-weight: bold;"><?php echo $engineno; ?></font>. has been fabricated by us and the same complies with the provisions of Motor Vehicles Act, 1988 and Rules made thereunder.</p>
<br>
<p style="text-align: right; line-height:50px; font-family: times new roman; font-size: 22px; font-style: normal">Signature of the Body Builder</p>

<br>


<p style="text-align: justify; line-height:50px; font-family: times new roman; font-size: 22px; font-style: normal">Form 22-A, Part I shall be issued with the signature of the body builder duly printed in the Form itself by affixing facsimile signature in ink under the hand and seal of the body builder.</p>
 </div>
  <form action="approval_process.php" method="POST">
  	<table>
	<input type="hidden" name="sid"  value="<?php echo $sid; ?>" />
	<input type="hidden" name="bid"  value="<?php echo $bid; ?>" />
		<tr>
			<td>
				
			</td>
			<td>
				<input type="submit" name="submit" value="Approve" style="margin-left: 400px; width:200px;height: 30px;background-color: #f14d0e;color: #fff;"/>
			
			</td>
		</tr>
	</table>
  </form>
   </div>
  

   
</body>
</html>
