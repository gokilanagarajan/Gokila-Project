<?php
session_start();//session start
$uname="sdf";$user_id="";$buyername="";$buyer_id="";$dobs="";
if(isset($_SESSION['username']))
	{
		$user_id= $_SESSION['user_id'];
		$uname ="Welcome to "."". $_SESSION['username'];
		
	}
	else{
		header('Location:index.php');
	}
	if(isset($_SESSION['buyername']))
	{
		$buyername= $_SESSION['buyername'];
		$dobs= $_SESSION['dobs'];
		include('db.php');
		$qu="select bid from buyer_info where buyer_name='$buyername' and buyer_dob='$dobs'";
		$re=mysql_query($qu);
		while($data=mysql_fetch_row($re))
		{
			$buyer_id=$data[0];
		}
		
	}
	?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title>ONLINE VEHICLE REGISTRATION SYSTEM</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width">
        <link href="css/style1.css" rel="stylesheet" type="text/css" />
		<link rel="stylesheet" href="css/sliding.css" type="text/css" media="screen" />
        <link rel="shortcut icon" href="./images/pwsicon.png">
     <script type="text/javascript">


function changeHashOnLoad() {
    window.location.href += "#";
    setTimeout("changeHashAgain()", "50"); 
}

function changeHashAgain() {
 window.location.href += "1";
}

var storedHash = window.location.hash;
window.setInterval(function () {
   if (window.location.hash != storedHash) {
        window.location.hash = storedHash;
   }
}, 50);

</script>

    </head>
<body onload="changeHashOnLoad();">
   <div class="wrapper">
       <img width="960" src="images/rtohead.png" alt=""/>
	   <div class="menu">
     <ul class="blue">
	<li><a href="userhome.php" title="Home"><span>Home</span></a></li>
	<li><a href="registerdetails.php" title="Registered Details" class="current" ><span>Registered Details</span></a></li>
    <li><a href="newregister.php" title="New Registration" ><span>New Registration</span></a></li>
    <li><a href="useravailableno.php" title="Vehicle Number"><span>Vehicle Numbers</span></a></li>
	
     <li><a href="contact.php" title="Contact" ><span>Contact</span></a></li>
	<li><?php echo $uname; ?></li>
	<li><a href="logout.php">Logout</a></li>
</ul>
</div>
  <div class="clear">
  </div>
  
   
   
 <div class="content">
 <h3 align="center">FORM 21</h3>

<h4 align="center">[See Rules 47(a) and (d)]</h4>
<h3 align="center" style="font-style: normal;">SALE CERTIFICATE</h3>
<p style="text-align: justify;">(To be issued by manufacturer/dealer or officer of Defense Department (in case of military auctioned vehicles) for presentation along with the application for registration of a motor vehicle).</p>
<br>
  <form action="form21_process.php" method="post">
  	<table>
	<input type="hidden" name="user_id" value="<?php echo $user_id; ?>"/>
	<input type="hidden" name="buyer_id" value="<?php echo $buyer_id; ?>"/>
		<tr>
			<td>
				(1).brand name of the vehicle
			</td>
			<td>
				<input type="text" name="brandname"/>
			</td>
			<td>
				(2).Delivered to
			</td>
			<td>
				<input type="text" name="deliveredto"/>
			</td>
		</tr>
		
		<tr>
			<td>
				(3).Delivered date
			</td>
			<td>
				<input type="date" name="delivereddate"/>
			</td>
			<td>
				(4).Name of the buyer
			</td>
			<td>
				<input type="text" name="buyer" value="<?php echo $buyername; ?>"/>
			</td>
			
		</tr>
		<tr>
			<td>
				(5).Son /wife/daughter
			</td>
			<td>
				<input type="text" name="guardian"/>
			</td>
			
			<td>
				(6).The vehicle is held under agreement of hire-purchase/lease/hypothecation with
			</td>
			<td>
				<input type="text" name="agreement"/>
			</td>
			
			
		</tr>
		
		<tr>
		<td>
				(7).Address (Permanent)
			</td>
			<td>
				<textarea rows="3" cols="30" name="permaddress"></textarea>
			</td>
			<td>
				(8).Address (Temporary)
			</td>
			<td>
				<textarea rows="3" cols="30" name="tempaddress"></textarea>
			</td>
			
		</tr>
		<tr>
			<td>The details of the vehicle are given below</td>
			<td></td>
		</tr>
		
		<tr>
			<td>
				<p style="font-style: arial;">(9).Class of Vehicle</p>
			</td>
	
			<td>
				<input type="text" name="classvehicle"/>
			</td>
				<td>
				(10).Maker's name
			</td>
			<td>
				<input type="text" name="makersname"/>
			</td>
		</tr>
		<tr>
			
			<td>
				(11).Chassis No.
			</td>
			<td>
				<input type="text" name="chasisno"/>
			</td>
		</tr>
		<tr>
			
			<td>
				(12).Engine No.
			</td>
			<td>
				<input type="text" name="engineno"/>
			</td>
		</tr>
		
		
		<tr>
			<td>
				(13).Horse power or cubic capacity
			</td>
			<td>
				<input type="text" name="cubiccapacity"/>
			</td>
			<td>
				(14).Fuel used
			</td>
			<td>
				<input type="text" name="fuelused"/>
			</td>
		</tr>
		
		<tr>
			<td>
				(15).Number of cylinders
			</td>
			<td>
				<input type="text" name="nocylinders"/>
			</td>
			<td>
				(16).Month and year of manufacture
			</td>
			<td>
				<input type="text" name="manufacturer"/>
			</td>
		</tr>
		
		<tr>
			<td>
				(17).Seating capacity(including driver)
			</td>
			<td>
				<input type="text" name="seating"/>
			</td>
			<td>
				(18).Unladen Weight
			</td>
			<td>
				<input type="text" name="unladen"/>
			</td>
		</tr>
		
		<tr>
			<td>
				(19).Maximum axle weight & number &
description of tyres (in case of transport vehicle
			</td>
			<td>
				
			</td>
			
		</tr>
		
		<tr>
			<td>
				(a) Front axle
			</td>
			<td>
				<input type="text" name="frontaxle"/>
			</td>
			<td>
				(b) Rear axle
			</td>
			<td>
				<input type="text" name="rearaxle"/>
			</td>
			
		</tr>
		<tr>
			<td>
				(c) Any other axle
			</td>
			<td>
				<input type="text" name="otheraxle"/>
			</td>
			<td>
				(d) Tandem axle
			</td>
			<td>
				<input type="text" name="tandemaxle"/>
			</td>
			
		</tr>
		
		
		<tr>
			<td>
				(20). Colour or colours of the body
			</td>
			<td>
				<input type="text" name="colors"/>
			</td>
			<td>
				(21).Gross vehicle weight
			</td>
			<td>
				<input type="text" name="grossvehicle"/>
			</td>
		</tr>
		
		<tr>
			<td>
				(22).Type of body
			</td>
			<td>
				<input type="text" name="typeofbody"/>
			</td>
			
		</tr>
		
		
		<tr>
			<td>
				
			</td>
			<td>
				<input type="submit" name="submit" value="Submit"/>
				<input type="reset" name="Reset"/>
			</td>
			
		</tr>
	</table>
  </form>
   </div>
 </div>
   
</body>
</html>
