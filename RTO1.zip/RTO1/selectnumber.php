<?php
session_start();//session start
$uname="";$user_id="";$dob="";$bdob="";$not="";
include('db.php');
if(isset($_SESSION['username']))
	{
		$user_id= $_SESSION['user_id'];
		$uname ="Welcome to "."". $_SESSION['username'];
		
	}
	else{
		header('Location:index.php');
	}
	$cata=$_POST['cata'];
	if('birth'==$cata)
	{
	$sql="select buyer_dob from buyer_info where user_id='$user_id'";
	$result=mysql_query($sql);
	while($data=mysql_fetch_row($result))
	{
		$dob=$data[0];
	}
	
	}
	if('purchase'==$cata)
	{
	$sql="select date from buyer_info where user_id='$user_id'";
	$result=mysql_query($sql);
	while($data=mysql_fetch_row($result))
	{
		$dob=$data[0];
	}
	
	}
	if('not-payable'==$cata)
	{
	$sql="select date,buyer_dob from buyer_info where user_id='$user_id'";
	$result=mysql_query($sql);
	while($data=mysql_fetch_row($result))
	{
		$dob=$data[0];
		$bdob=$data[1];
	}
	
	}
	
	
	?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title>ONLINE VEHICLE REGISTRATION SYSTEM</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width">
        <link href="css/style1.css" rel="stylesheet" type="text/css" />
		<link rel="stylesheet" href="css/sliding.css" type="text/css" media="screen" />
        <link rel="shortcut icon" href="./images/pwsicon.png">
    

    </head>
<body >
   <div class="wrapper">
       <img width="960" src="images/rtohead.png" alt=""/>
	   <div class="menu">
     <ul class="blue">
	<li><a href="userhome.php" title="Home"><span>Home</span></a></li>
	<li><a href="registerdetails.php" title="Registered Details" class="current"><span>Registered Details</span></a></li>
   
    <li><a href="useravailableno.php" title="Vehicle Number"><span>Vehicle Numbers</span></a></li>
	
    <li><a href="contact.php" title="Contact"><span>Contact</span></a></li>
	<li><font color="#f9600d"> <?php echo $uname; ?></font></li>
	<li><a href="logout.php">Logout</a></li>
</ul>
</div>
  <div class="clear">
  </div>
  
   
   
 <div class="content">
 <br>
 <div class="clear"></div>
 <h3>Select Number </h3>
  <?php 
  $rtoid=$_POST['rtoid'];
  $bid=$_POST['bid'];
  $rest = substr($dob, 8, 9);
   $rest1 = substr($bdob, 8, 9);
 
  ?>
 
  <ul>	
  <?php
  include('db.php');
  
  
  $uptono="";$x=0001;
  $arr = Array();
  $query="select * from l_rto_regist where rto_id=$rtoid";
  	$sql="select b.bike_no from l_users u,l_rto_regist l,buyer_info b where l.rto_id=$rtoid and l.rto_id=u.rto and u.user_id=b.user_id;";
  $result=mysql_query($query);
  while($data=mysql_fetch_row($result))
  {
  	$uptono=$data[4];
	for ($x; $x<=$uptono; $x++) {
	$tt=0;
		  $res=mysql_query($sql);
		  while($data1=mysql_fetch_row($res))
		  {
		  	$arr[]=$data1[0];
		}
		if (!in_array($x, $arr)) 
		{
			if('purchase'==$cata || 'birth'==$cata )
			{
				if (strpos($x,$rest) !== false) {
					$num =sprintf("%04s", $x);
					
					echo '<li><a href="payment.php?bid='.$bid.'&no='.$num.'" onclick="return confirm(\'Are you sure buy the Number?\')" >'.$num.'</a></li>';
					}
			}
			if('fancy'==$cata)
			{
				$num =sprintf("%04s", $x);
				if (preg_match('/(.)\\1{1}/', $num))
				
				echo '<li><a href="payment.php?bid='.$bid.'&no='.$num.'" onclick="return confirm(\'Are you sure buy the Number?\')" >'.$num.'</a></li>';
				
				
			}
			else
			{
				$num =sprintf("%04s", $x);
				if (!preg_match('/(.)\\1{1}/', $num))
				if (strpos($num,$rest) !== false) {
					if (strpos($num,$rest1) !== false) {
					
				echo '<li><a href="notpayment.php?bid='.$bid.'&no='.$num.'" onclick="return confirm(\'Are you sure buy the Number?\')" >'.$num.'</a></li>';
				break;
				}
				}
			}
			
				
			?>
 
  <?php 
		
		}
  }
  }
  ?>
 
 </ul>	
   </div>
 </div>
   
</body>
</html>
