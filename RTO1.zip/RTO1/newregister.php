<?php
session_start();//session start
$uname="sdf";$user_id="";
if(isset($_SESSION['username']))
	{
		$user_id= $_SESSION['user_id'];
		$uname ="Welcome to "."". $_SESSION['username'];
		
	}
	else{
		header('Location:index.php');
	}
	
	?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title>ONLINE VEHICLE REGISTRATION SYSTEM</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width">
        <link href="css/style1.css" rel="stylesheet" type="text/css" />
		<link rel="stylesheet" href="css/sliding.css" type="text/css" media="screen" />
        <link rel="shortcut icon" href="./images/pwsicon.png">
     <script type="text/javascript">


function changeHashOnLoad() {
    window.location.href += "#";
    setTimeout("changeHashAgain()", "50"); 
}

function changeHashAgain() {
 window.location.href += "1";
}

var storedHash = window.location.hash;
window.setInterval(function () {
   if (window.location.hash != storedHash) {
        window.location.hash = storedHash;
   }
}, 50);

</script>

    </head>
<body onload="changeHashOnLoad();">
   <div class="wrapper">
       <img width="960" src="images/rtohead.png" alt=""/>
	   <div class="menu">
     <ul class="blue">
	<li><a href="userhome.php" title="Home"><span>Home</span></a></li>
	<li><a href="registerdetails.php" title="Registered Details" class="current" ><span>Registered Details</span></a></li>
    
    <li><a href="#" title="Vehicle Number"><span>Vehicle Numbers</span></a></li>
	
    <li><a href="contact.php" title="Contact" ><span>Contact</span></a></li>
	<li><?php echo $uname; ?></li>
	<li><a href="logout.php">Logout</a></li>
</ul>
</div>
  <div class="clear">
  </div>
  
   
   
 <div class="content">
 <br>
 <h3 align="center">Buyer Basic Information</h3>
  <form action="newreg_process.php" method="POST">
  <table align="center">
  <input type="hidden" name="user_id" value="<?php echo $user_id; ?>"/>
  <tr>
		<td>
			Today Date
		</td>
		<td>
			<input type="date" name="date" required="true"/>
		</td>
	</tr>
  	<tr>
		<td>
			Buyer Name
		</td>
		<td>
			<input type="text" name="buyername" required="true"/>
		</td>
	</tr>
	<tr>
		<td>
			DOB
		</td>
		<td>
			<input type="date" name="dob" required="true"/>
		</td>
	</tr>
	<tr>
		<td>
			Contact Number
		</td>
		<td>
			<input type="text" name="mobile" required="true"/>
		</td>
	</tr>
	<tr>
		<td></td>
		<td></td>
	</tr>
	<tr>
		<td></td>
		<td><input type="submit" value="Submit"/>
		<input type="reset" value="Reset"/></td>
	</tr>
  </table>
  	
  </form>
   </div>
 </div>
   
</body>
</html>
