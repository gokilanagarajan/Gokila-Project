<?php
    include('db.php');
	$bikeno=$_GET['no'];
	$bid=$_GET['bid'];
	$sql="update buyer_info set bike_no='$bikeno' where bid=$bid";
	$res=mysql_query($sql);
	if($res)
	{
	 $url='registerdetails.php';
	 echo '<script language="javascript">alert("Your Selected");location.href=\'' . $url . '\'</script>';
	}
	else
	{
		
	}
?>